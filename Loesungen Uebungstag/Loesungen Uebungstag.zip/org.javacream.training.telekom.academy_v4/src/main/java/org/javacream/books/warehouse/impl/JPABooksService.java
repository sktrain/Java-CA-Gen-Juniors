package org.javacream.books.warehouse.impl;

import org.javacream.books.isbngenerator.api.IsbnGenerator;
import org.javacream.books.warehouse.api.Book;
import org.javacream.books.warehouse.api.BookException;
import org.javacream.books.warehouse.api.BooksService;
import org.javacream.store.api.StoreService;
import org.javacream.util.Ordering;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.stream.Collectors;

@Component
public class JPABooksService implements BooksService{

	@Autowired
	private StoreService storeService;
	@Autowired
	private IsbnGenerator isbnGenerator;

	@Autowired
	private BookRepo repo;

	@Override
	public String newBook(String title, double price, Map<String, Object> options) throws BookException {
		String isbn = isbnGenerator.next();
		System.err.println(isbn);
		Book book = new Book();
		book.setIsbn(isbn);
		book.setTitle(title);
		book.setPrice(price);
		repo.save(book);
		return isbn;
	}

	@Override
	public Book findBookByIsbn(String isbn) throws BookException {
		Optional<Book> result = repo.findById(isbn);
		if (result.isEmpty()) {
			throw new BookException(BookException.BookExceptionType.NOT_FOUND, isbn);
		}
		int stock = storeService.getStock("books", isbn);
		Book book = result.get();
		book.setAvailable(stock > 0);
		return book;
	}

	@Override
	public Book updateBook(Book bookDetailValue) throws BookException {
		if (bookDetailValue.getPrice() <= 0) {
			throw new BookException(BookException.BookExceptionType.CONSTRAINT, "price <= 0");
		}
		return repo.save(bookDetailValue);
	}

	@Override
	public void deleteBookByIsbn(String isbn) throws BookException {
		repo.deleteById(isbn);
		if (repo.existsById(isbn)) {
			throw new BookException(BookException.BookExceptionType.NOT_DELETED, isbn);
		}
	}

	@Override
	public Collection<Book> findAllBooks() {
		return repo.findAll();
	}


	@Override
	public  List<Book> findBooksByType(Class<? extends Book> type) {
		return findAllBooks().stream().filter((book) -> book.getClass().isAssignableFrom(type))
				.collect(Collectors.toList());
	}

	@Override
	public  List<Book> findBooksByPriceRange(double minPrice, double maxPrice) {
		return repo.findBooksByPriceBetweenOrderByIsbn(minPrice, maxPrice);
	}

	@Override
	public List<Book> findBooksByTitleCriterion(String expression) {
		return repo.getBooksForMatch(expression);
		// im Fall von H2 kann dies die Datenbank dank Support für regular expressions
//		return findAllBooks().stream().filter((book) -> book.getTitle().matches(expression))
//				.collect(Collectors.toList());
	}

	@Override
	public List<Book> booksList(Ordering ordering) {
		switch (ordering) {
		case ASCENDING: {
			return repo.findAll(Sort.by("isbn"));
//			return findAllBooks().stream().sorted((book1, book2) -> book1.getIsbn().compareTo(book2.getIsbn()))
//					.collect(Collectors.toList());
		}
		case DESCENDING: {
			return repo.findAll(Sort.by("isbn").descending());
//			return findAllBooks().stream().sorted((book1, book2) -> book2.getIsbn().compareTo(book1.getIsbn()))
//					.collect(Collectors.toList());
		}
		default: {
			return repo.findAll(Sort.by("isbn"));
//			return findAllBooks().stream().sorted((book1, book2) -> book1.getIsbn().compareTo(book2.getIsbn()))
//					.collect(Collectors.toList());
		}
		}
	}

	@Override
	public List<Book> booksList() {
		return booksList(Ordering.ASCENDING);
	}



}
