package appl;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import processor.GroupChangeProcessor;


public class Application {
	public static void main(String[] args) {
//		try (ClassPathXmlApplicationContext beanFactory = new ClassPathXmlApplicationContext("spring.xml")) {
//			GroupChangeProcessor p = (GroupChangeProcessor) beanFactory.getBean("gcp");
//			p.run();
//		}
		
		//Context anhand Component-Scan f�r Package "processor.impl"
		try (AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext("processor.impl"))
		{
			//GroupChangeProcessor p = (GroupChangeProcessor) ctx.getBean("groupChangeProcessorImpl");
			GroupChangeProcessor p = (GroupChangeProcessor) ctx.getBean(GroupChangeProcessor.class);
			p.run();
		}
	}
}
