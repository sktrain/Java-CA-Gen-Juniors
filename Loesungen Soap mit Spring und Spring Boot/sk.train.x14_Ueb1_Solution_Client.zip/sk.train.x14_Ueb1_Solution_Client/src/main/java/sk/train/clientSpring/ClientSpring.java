package sk.train.clientSpring;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import sk.train.handisch.Student;
import sk.train.handisch.WsServiceIF;

public class ClientSpring {

    public static void main(String[] args) {

        try (AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext(ClientConfiguration.class)) {

           WsServiceIF proxy = (WsServiceIF) ctx.getBean("client");

            String answer = proxy.hello("Karrer");
            System.out.println(answer);

            Student student = new Student("Hugo");
            System.out.println(proxy.register(student));
        }


    }


}
