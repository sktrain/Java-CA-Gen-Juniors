package appl;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import beans.MathService;

public class Application {
	public static void main(String[] args) {
		try (final ClassPathXmlApplicationContext ctx = 
				new ClassPathXmlApplicationContext("spring.xml")) {
			final MathService sumService = ctx.getBean(MathService.class);
			System.out.println(sumService.sum(40, 2));
			System.out.println(sumService.diff(80, 3));
		}
	}
}
