/* Nur Controller-Test */

package app;

import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.boot.test.mock.mockito.MockBean;
import app.dao.EmpRepository;
import app.model.Employee;
import app.web.EmployeeController;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

//@SpringBootTest()
@WebMvcTest(EmployeeController.class)
public class ControllerOnlyTest {
	
	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private EmpRepository repo;
	
	@Test
	void contextLoads() {
	}
	
		
//	@Test
//	public void testempByiD(){
//		//Mock für Repository konfigurieren
//		Employee king = new Employee(); king.setLastName("King");
//		when(repo.findById(100L)).thenReturn(Optional.of(king));
//		//Mock für MVC nutzen
//		mockMvc.perform(get("employee/100")).andDo(print()).andExpect(status().isOk()).andExpect(jsonPath("$.lastName").value(king.getLastName()));
//		
//	}

	
	// noch zu Testen:

//	@PostMapping
//	public Employee saveEmp(@RequestBody Employee emp) {
//		if (repo.existsById(emp.getEmployeeId())) {
//			throw new EmployeeExistsException("Employee exists for id: " + emp.getEmployeeId());
//		}
//		return repo.save(emp);
//	}
//
//	@PutMapping("/{id}")
//	public Employee updateEmp(@PathVariable("id") Long id, @RequestBody Employee emp) {
//		if (repo.existsById(id)) {
//			return repo.save(emp);
//		} else {
//			throw new EmployeeNotFoundException("No Employee for id: "+ id);
//		}
//	}
//	
//	@DeleteMapping("/{id}")
//	public void deleteEmp(@PathVariable("id") Long id) {
//		if (repo.existsById(id)) {
//			repo.deleteById(id);  //wirft nur IllegalArgumentException falls ID null
//		} else {
//			throw new EmployeeNotFoundException("No Employee for id: "+ id);
//		}
//	}


	
}
