package sk.train.ma.strategy.model;

import java.io.Serializable;
import java.math.BigDecimal;

public interface Gehaltsmodell extends Serializable {
	
	public abstract BigDecimal getGehalt();
	
}
