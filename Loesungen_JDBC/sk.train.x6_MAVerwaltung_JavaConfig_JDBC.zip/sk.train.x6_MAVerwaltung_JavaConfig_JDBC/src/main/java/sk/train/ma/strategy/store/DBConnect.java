package sk.train.ma.strategy.store;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnect {
	
	private Connection myconnect;
	
	public Connection createConnection() {
		try {
			Class.forName("org.h2.Driver");
			myconnect = DriverManager.getConnection("jdbc:h2:tcp://localhost/~/test", "sa", "");
			return myconnect;
		} catch (ClassNotFoundException e) {
			throw new RuntimeException(e);
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}

	}
	
	public void closeConnection() {
		try {
			myconnect.close();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}

}
