package servlets;

import beans.MyBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.springframework.web.context.WebApplicationContext;

@Configuration
public class AppConfig {

    @Bean(name ="requestBean")
    // @Scope("request")
    @Scope(WebApplicationContext.SCOPE_REQUEST)
    public MyBean requestBean() {
        return new MyBean("request");
    }
    @Bean(name ="sessionBean")
    // Scope("session")
    @Scope(WebApplicationContext.SCOPE_SESSION)
    public MyBean sessionBean() {
        return new MyBean("session");
    }
    @Bean(name ="applicationBean")
    //@Scope("application")
    @Scope(WebApplicationContext.SCOPE_SESSION)
    public MyBean applicationBean() {
        return new MyBean("application");
    }
    @Bean(name ="singletonBean")
    @Scope("singleton")
    public MyBean singletonBean() {
        return new MyBean("singleton");
    }
}
