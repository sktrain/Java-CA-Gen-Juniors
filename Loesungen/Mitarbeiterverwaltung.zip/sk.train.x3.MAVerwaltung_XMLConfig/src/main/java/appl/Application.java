package appl;

import java.util.Comparator;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.TableModel;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import sk.train.ma.strategy.verwaltung.MitarbeiterVerwaltungIf;

public class Application {
	public static void main(String[] args) {
		try (final ClassPathXmlApplicationContext ctx = 
				new ClassPathXmlApplicationContext("spring.xml")) {
			
//			MitarbeiterVerwaltungIf mv = ctx.getBean(MitarbeiterVerwaltungIf.class);
//			
//			System.out.println(ctx.getBean(Comparator.class));
//			
//			System.out.println(ctx.getBean("maliste").getClass());
//			
//			System.out.println(ctx.getBean("tablemodel"));
			
//			TableModel model = ctx.getBean("tablemodel", TableModel.class);
			
//			TableModel model = ctx.getBean("tablemodel2", TableModel.class);
			
			TableModel model = ctx.getBean("tablemodel3", TableModel.class);
			
			JFrame f = new JFrame();
			JTable mytable = new JTable(model);
			JScrollPane p = new JScrollPane(mytable);
			f.add(p);
			f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			f.pack();
			f.setVisible(true);
			
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			((AbstractTableModel) model).fireTableCellUpdated(0, 1);
			
		}
	}
}
