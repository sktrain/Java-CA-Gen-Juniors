package somewhere;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import beans.DiffServiceImpl;
import beans.SumServiceImpl;
import ifaces.DiffService;
import ifaces.SumService;
import jn.util.Log;

@Configuration
public class SumDiffConfiguration {

	public SumDiffConfiguration() {
		Log.log();
	}
	
	@Bean 
	public SumService getSumService() {
		Log.log();
		return new SumServiceImpl();
	}

	@Bean 
	public DiffService getDiffService() {
		Log.log();
		return new DiffServiceImpl();
	}
}
