package sk.train.app;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import model.Department;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import model.Employee;
import sk.train.repositories.DepRepository;
import sk.train.repositories.EmpRepository;

public class Application {
    public static void main(String[] args) {

        // EmpService anhand Context beziehen und nutzen

        try (final AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext(
                sk.train.app.ApplConfig.class)) {

            EmpRepository myserv = ctx.getBean(EmpRepository.class);

            DepRepository myservDep = ctx.getBean(DepRepository.class);

            Employee emp = new Employee();
            emp.setEmployeeId(471);
            emp.setFirstName("Max");
            emp.setLastName("Mustermann");
            emp.setHireDate(new Date());
            emp.setJobId("IT_PROG");
            emp.setPhoneNumber("1111");
            emp.setSalary(new BigDecimal(5000l));
            emp.setEmail("Mustermann@murks.de" + 4711);


            Employee erg = myserv.save(emp);
            System.out.println(erg == emp);


            Optional<Employee> emp1 = myserv.findById(471L);
            System.out.println(emp1);


            emp.setSalary(new BigDecimal(8000L));
            erg = myserv.save(emp);
            System.out.println(erg == emp);

            emp1 = myserv.findById(471L);
            if (emp1.isPresent()) {
                System.out.println(emp1.get().getSalary());
            }

            myserv.deleteById(471L);

            myserv.findAll().forEach(System.out::println);

            System.out.println("\n ********************* jetzt zu den Departments *************\n");

            List<Department> deplist = myservDep.findAll();
            deplist.forEach(System.out::println);

            Optional<Department> optionalDepartment = myservDep.findById(50L);
            if (optionalDepartment.isPresent()) {
                System.out.println("Hier kommt der Abteilungsleiter: " + optionalDepartment.get().getEmployee().getLastName());

                //jetzt mal alle Angestellten
//                System.out.println("\n ********************* alle Angestellten *************\n");
//                optionalDepartment.get().getEmployees().forEach(employee -> System.out.println(employee.getLastName()));
            }

            //jetzt mal Angestellten anhand des Departments (join fetch Variante)
            optionalDepartment = myservDep.getDepartmentWithEmps(50L);
            if (optionalDepartment.isPresent()) {
                System.out.println("\n ********************* alle Angestellten per join fetch*************\n");
                optionalDepartment.get().getEmployees().forEach(employee -> System.out.println(employee.getLastName()));

            }


            //jetzt mal Angestellten anhand des Departments (Entity Graph Variante)
            optionalDepartment = myservDep.getDepartmentWithEmpsByGraph(50L);
            if (optionalDepartment.isPresent()) {
                System.out.println("\n ********************* alle Angestellten per Entity Graph *************\n");
                optionalDepartment.get().getEmployees().forEach(employee -> System.out.println(employee.getLastName()));

            }
        }

    }
}
