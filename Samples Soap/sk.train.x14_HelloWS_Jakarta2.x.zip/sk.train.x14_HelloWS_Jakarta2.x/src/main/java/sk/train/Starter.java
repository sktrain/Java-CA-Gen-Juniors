package sk.train;

import javax.xml.ws.Endpoint;

public class Starter {

    public static void main(String[] args) {
        Endpoint.publish("http://localhost:8888/hellows", new HelloImpl());
    }
}
