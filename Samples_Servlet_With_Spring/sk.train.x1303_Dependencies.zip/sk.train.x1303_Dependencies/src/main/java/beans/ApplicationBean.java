package beans;

public class ApplicationBean {
	public ApplicationBean() {
		System.out.println(this.getClass().getSimpleName() + "()");
	}
}
