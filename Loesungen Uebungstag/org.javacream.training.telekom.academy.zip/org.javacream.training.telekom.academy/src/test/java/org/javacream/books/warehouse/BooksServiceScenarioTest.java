//package org.javacream.books.warehouse;
//
//import static org.junit.Assert.assertNotNull;
//import static org.junit.Assert.assertTrue;
//import static org.junit.Assert.fail;
//
//import java.util.Collection;
//import java.util.HashMap;
//
//import org.javacream.books.warehouse.api.Book;
//import org.javacream.books.warehouse.api.BookException;
//import org.javacream.books.warehouse.api.BooksService;
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.test.context.ActiveProfiles;
//import org.springframework.test.context.junit4.SpringRunner;
//
//
//@RunWith(SpringRunner.class)
//@SpringBootTest
//@ActiveProfiles("test")
//public class BooksServiceScenarioTest {
//
//	@Autowired
//	private BooksService booksService;
//
//	@Test
//	public void testBooksSequence() {
//		doTest(booksService);
//	}
//
//	private void doTest(BooksService booksService) {
//
//		try {
//			Collection<Book> books = booksService.findAllBooks();
//			final int startSize = books.size();
//			String j2eeTitle = "Spring";
//			String isbn = booksService.newBook(j2eeTitle, 19.99, new HashMap<String, Object>());
//			books = booksService.findAllBooks();
//			final int endSize = books.size();
//			assertTrue(endSize == startSize + 1);
//			assertNotNull(isbn);
//			assertNotNull(booksService.findBookByIsbn(isbn));
//
//			try {
//				booksService.findBookByIsbn("ISBN-3");
//				fail("BookException must be thrown!");
//			} catch (BookException e) {
//				// OK
//			}
//			booksService.deleteBookByIsbn(isbn);
//			assertTrue(startSize == booksService.findAllBooks().size());
//			try {
//				booksService.deleteBookByIsbn(isbn);
//				fail("BookException must be thrown!");
//			} catch (BookException e) {
//				// OK
//			}
//
//		} catch (BookException bookException) {
//			bookException.printStackTrace();
//			fail(bookException.getMessage());
//		}
//
//	}
//
//}
