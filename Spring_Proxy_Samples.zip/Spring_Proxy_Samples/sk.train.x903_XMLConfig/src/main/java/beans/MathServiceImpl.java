package beans;

import iface.MathService;

public class MathServiceImpl implements MathService {
	final String MESSAGE = "only positive parameters allowed";
	@Override
	public int sum(int x, int y) {
		if (x <= 0 || y <= 0)
			throw new RuntimeException(this.MESSAGE);
		return x + y;
	}
	@Override
	public int diff(int x, int y) {
		if (x <= 0 || y <= 0)
			throw new RuntimeException(this.MESSAGE);
		return x - y;
	}
}