Web-Projekt mit Spring-Security mit Passwort-Datenbank+ Autorisierung


Basiert auf sk.train.x14_04_JPA_Rest_SOAP_Boot_Solution

(Rest mit JPA, Spring Boot und XML-MessageFormat mit Jackson
+ zusätzlich als SOAP-WS mit CXF aufrufbar: http://localhost:8088/services/jaxwsemployee?wsdl
)

