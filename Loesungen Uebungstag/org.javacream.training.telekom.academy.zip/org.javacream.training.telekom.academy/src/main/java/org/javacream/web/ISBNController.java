package org.javacream.web;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(value = "/isbn")
public class ISBNController {

    @PostMapping(value="/new")
    public void createISBN( @RequestBody String isbn){
        System.out.println(isbn);
    }

}
