package appl;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import iface.MathService;

public class Application {
	public static void main(String[] args) {
		try (ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("spring.xml")) {

			final MathService mathService = ctx.getBean(MathService.class);

			System.out.println(mathService.getClass().getName());
			System.out.println(mathService.sum(40, 2));
			System.out.println(mathService.diff(80, 3));

			final Class<?>[] ifaces = mathService.getClass().getInterfaces();
			System.out.println("interfaces");
			for (final Class<?> iface : ifaces)
				System.out.println("\t" + iface.getName());
		}
	}
}
