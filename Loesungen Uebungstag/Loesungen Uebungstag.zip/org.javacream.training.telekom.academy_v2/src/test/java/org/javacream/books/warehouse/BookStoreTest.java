package org.javacream.books.warehouse;

import org.javacream.books.warehouse.api.BookException;
import org.javacream.books.warehouse.api.BooksService;
import org.javacream.store.api.StoreService;
import org.javacream.store.impl.JpaStoreService;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.HashMap;

@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("dev")
public class BookStoreTest {

    @Autowired
    private JpaStoreService storeService;  //da das Interface nur die get-Methode definiert

    @Test        //quasi schon Test für Stock-Speicherung
    public void initialize() throws BookException {
        storeService.setStock("books", "testisbn", 10);
        Assert.assertEquals(10, storeService.getStock("books", "testisbn"));
    }
}
