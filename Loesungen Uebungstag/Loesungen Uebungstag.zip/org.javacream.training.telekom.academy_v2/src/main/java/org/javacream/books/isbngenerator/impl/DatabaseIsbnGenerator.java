package org.javacream.books.isbngenerator.impl;

import java.util.Random;

import org.javacream.books.isbngenerator.api.ISBNValue;
import org.javacream.books.isbngenerator.api.IsbnGenerator;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

@Component
public class DatabaseIsbnGenerator implements IsbnGenerator{

	private Random random;
	
	public DatabaseIsbnGenerator(@Value("${isbngenerator.prefix}") String prefix, @Value("${isbngenerator.suffix}")String suffix) {
		if (prefix == null || suffix ==  null) {
			throw new IllegalArgumentException ("prefix and suffix must not be null");
		}
		this.prefix = prefix;
		this.suffix = suffix;
		random = new Random(this.hashCode() + System.currentTimeMillis());
	}
	private String prefix;
	private String suffix;
	

	@PersistenceContext
	private EntityManager em;
	@Override
	@Transactional
	public String next() {

		ISBNValue value = new ISBNValue();
		em.persist(value);
		System.err.println(value.getId());
		return prefix + value.getId() + suffix;
	}

}
