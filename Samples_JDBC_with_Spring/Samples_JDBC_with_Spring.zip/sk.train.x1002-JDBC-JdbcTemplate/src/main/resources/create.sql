DROP TABLE ACCOUNT;
create table account (
	number integer,
	balance integer,
	primary key (number)
);
