
sk.train.ma.strategy:

- Basisversion der Mitarbeiterklasse mit Gehaltsmodell (Has-A), 
  Gehaltsmodelle sind per Interface definiert (Strategy-Pattern umgesetzt)
- Entsprechend kann die Mitarbeiterverwaltung die Gehaltssumme liefern
- Mitarbeiterverwaltung ist auf Map umgestellt und Methodik erweitert
- Methode, die das Sortierkriterium als Baustein erwartet und entsprechende Liste
  liefert, ist in der Mitarbeiterverwaltung vorhanden
- Mitarbeiterklasse implementiert Comparable
- Klassen haben Standardmethoden (toString, equals, hashcode) überschrieben
- Ausgabe der MItarbeiterverwaltung in Textdatei
- Ergänzt um GUI-Komponente via Swing JTable
- Mitarbeiterverwaltung umgestellt auf Spring-Java-Konfiguration
- Komponenten umgestellt, so dass Abhängigkeiten injiziert werden können
- Statisch umgestellt auf Instanz (Nutzen des Singleton-Modells von Spring)
- Interfaces komplettiert

Aufgabe: FixgehaltMitarbeiter via JDBC aus der H2-Datenbank verwalten:
- Es wird erstmal nur gelesen, d.h. der JTable zeigt den Inhalt der EMPLOYEES-Tabelle an
- Statt dem Store-Service benutzt die Mitarbeiterverwaltung jetzt eine Datenbank-Verbindung,
  um die Map aufzubauen
- Factory für Gehaltsmodelle und der Store-Service wird nicht mehr benötigt
- Abbildung Employee auf Fixgehalt-Mitarbeiter:
      - Geburtsdatum ist in der DB nicht vorhanden: auf 1.1.1900 setzen
      - Geschlecht ist in der DB nicht vorhanden: auf Divers setzen
      - Spalten aus der DB, die nicht im Mitarbeiter vorhanden sind, werden ignoriert

