package appl;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import util.GuiParams;

public class Application {
	public static void main(String[] args) {
		try (final AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext("util")) {
			final GuiParams gui = ctx.getBean(GuiParams.class);
			System.out.println(gui);
		}
	}
}
