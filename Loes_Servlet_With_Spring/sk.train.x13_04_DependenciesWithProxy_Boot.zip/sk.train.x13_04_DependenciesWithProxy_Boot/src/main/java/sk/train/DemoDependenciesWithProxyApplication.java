package sk.train;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.web.context.WebApplicationContext;
import sk.train.beans.ApplicationBean;
import sk.train.beans.RequestBean;
import sk.train.beans.SessionBean;
import sk.train.servlets.MyServlet;

@SpringBootApplication
public class DemoDependenciesWithProxyApplication {

    public static void main(String[] args) {

        ConfigurableApplicationContext ctx = SpringApplication.run(DemoDependenciesWithProxyApplication.class, args);

    }

    @Bean
    public ServletRegistrationBean<MyServlet> helloServ(){
        return new ServletRegistrationBean<>(
                new MyServlet(), "/scopesproxy"
        );
    }

    @Bean(name ="requestBean")
    @Scope(value = WebApplicationContext.SCOPE_REQUEST, proxyMode= ScopedProxyMode.TARGET_CLASS)
    public RequestBean requestBean() {
        return new RequestBean();
    }

    @Bean(name ="sessionBean")
    @Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode=ScopedProxyMode.TARGET_CLASS)
    public SessionBean sessionBean() {
        return new SessionBean(requestBean());
    }

    @Bean(name ="applicationBean")
    @Scope(WebApplicationContext.SCOPE_APPLICATION)
    public ApplicationBean applicationBean() {
        return new ApplicationBean(sessionBean());
    }


}
