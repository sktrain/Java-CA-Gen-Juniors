
sk.train.ma.strategy:

- Basisversion der Mitarbeiterklasse mit Gehaltsmodell (Has-A), 
  Gehaltsmodelle sind per Interface definiert (Strategy-Pattern umgesetzt).
  Factory-Methode wäre hier möglich, aber leider kein static Initializer
- Entsprechend kann die Mitarbeiterverwaltung die Gehaltssumme liefern
- Mitarbeiterverwaltung ist auf Map umgestellt und Methodik erweitert
- Methode, die das Sortierkriterium als Baustein erwartet und entsprechende Liste
  liefert, ist in der Mitarbeiterverwaltung vorhanden
- Mitarbeiterklasse implementiert Comparable
- Klassen haben Standardmethoden (toString, equals, hashcode) überschrieben
- Factory für Gehaltsmodelle ist vorhanden (static Initializer kann nicht im Interface verwendet werden)
- Factory wird per Properties gefüttert
- Ausgabe der MItarbeiterverwaltung in Textdatei
- Ergänzt um GUI-Komponente via Swing JTable


