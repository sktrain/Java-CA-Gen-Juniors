package beans;

import ifaces.Listener;
import ifaces.SumService;

public class SumServiceImpl implements SumService {
	private Listener listener;
	public void setListener(Listener listener) {
		this.listener = listener;
	}
	public int sum(int x, int y) {
		if (this.listener != null)
			this.listener.notify("sum(" + x + ", " + y + ")");
		return x + y;
	}
}
