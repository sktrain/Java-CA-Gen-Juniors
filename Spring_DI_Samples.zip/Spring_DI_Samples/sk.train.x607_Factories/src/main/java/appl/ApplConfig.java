package appl;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;

import jn.util.Log;

@Configuration
public class ApplConfig {
	
	public ApplConfig() {
		Log.log();
	}

	@Bean(name = "Hello")
	public String hello() {
		Log.log();
		return "Hello";
	}

	@Bean(name = "World")
	@Lazy
	public String world() {
		Log.log();
		return "World";
	}
}
