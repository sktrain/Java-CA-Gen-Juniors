package sk.train.handisch;

import javax.xml.namespace.QName;
import javax.xml.ws.Service;
import java.net.MalformedURLException;
import java.net.URL;

public class ClientStandard {

    public static void main(String[] args) throws MalformedURLException {

        final QName SERVICE_NAME
                = new QName("http://train.sk/", "WsServiceIFService");

        URL url = new URL("http://localhost:8080/sk.train.x14_Ueb1_Solution-1.0-SNAPSHOT/services/hello_world?wsdl");

        Service serv = Service.create(url, SERVICE_NAME);

        WsServiceIF proxy = serv.getPort(WsServiceIF.class);

        String answer = proxy.hello("Karrer");
        System.out.println(answer);

        Student student = new Student("Hugo");
        System.out.println(proxy.register(student));

    }
}
