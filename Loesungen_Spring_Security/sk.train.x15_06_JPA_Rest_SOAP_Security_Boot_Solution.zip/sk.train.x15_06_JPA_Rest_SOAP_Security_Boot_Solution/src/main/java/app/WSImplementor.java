package app;

import app.dao.EmpRepository;
import app.model.Employee;
import app.web.EmployeeExistsException;
import app.web.EmployeeNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import javax.jws.WebService;
import java.util.List;
import java.util.Optional;

@WebService(endpointInterface = "app.WSImplementorIF")
public class WSImplementor implements WSImplementorIF {


    private EmpRepository repo;

    @Autowired
    public void setRepository(EmpRepository repo){
        this.repo = repo;
    }

    @Override
    public List<Employee> allEmps() {
        return repo.findAll();
    }

    @Override
    public Employee saveEmp(Employee emp) {
        if (repo.existsById(emp.getEmployeeId())) {
            throw new EmployeeExistsException("Employee exists for id: " + emp.getEmployeeId());
        }
        return repo.save(emp);
    }

    @Override
    public Employee empById(Long id) {
        Optional<Employee> optemp = repo.findById(id);
        return optemp.orElseThrow(() -> new EmployeeNotFoundException("No Employee for id: " + id));
    }
}
