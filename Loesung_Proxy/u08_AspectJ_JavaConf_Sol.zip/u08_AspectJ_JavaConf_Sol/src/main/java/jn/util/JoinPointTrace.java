package jn.util;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.Signature;

public class JoinPointTrace {
	public static void trace(String text, JoinPoint joinPoint, Object result) {
		final Signature signature = joinPoint.getSignature();
		System.out.print(text + signature.getDeclaringTypeName() + "." + signature.getName() + "(");
		final Object[] args = joinPoint.getArgs();
		if (args != null)
			for (int i = 0; i < args.length; i++) {
				if (i > 0)
					System.out.print(", ");
				System.out.print(args[i]);
			}
		System.out.print(")");
		if (result != null)
			System.out.print(" --> " + result);
		System.out.println();
	}
}
