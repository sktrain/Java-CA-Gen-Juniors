Ein Spring Boot Servlet Projekt

Port des Embbedded Tomcat ist vorsichtshalber auf "8888" gesetzt.
(siehe application.properties)