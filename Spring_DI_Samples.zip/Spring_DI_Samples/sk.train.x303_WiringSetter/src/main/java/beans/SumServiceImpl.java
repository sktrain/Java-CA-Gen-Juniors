package beans;

import ifaces.SumService;
import jn.util.Log;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SumServiceImpl implements SumService {

	private static Logger logger = LoggerFactory.getLogger("sk.train");
	public SumServiceImpl() { 
		Log.log();
		logger.info("Konstruktor {}", this.getClass());
	}
	@Override
	public int sum(int x, int y) {
		return x + y;
	}
}
