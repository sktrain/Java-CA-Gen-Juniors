package beans;

import java.text.DateFormat;
import java.util.Date;

public class MyBean {

	private final String springScope;
	private final Date dateCreated;

	public MyBean(String springScope) {
		this.springScope = springScope;
		this.dateCreated = new Date();;
	}

	@Override
	public String toString() {
		return Integer.toHexString(System.identityHashCode(this)) + " " + this.springScope
				+ " " + DateFormat.getTimeInstance().format(this.dateCreated);
	}
}