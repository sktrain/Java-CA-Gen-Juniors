package processor;

import domain.Customer;
import domain.Order;
import domain.Product;

public interface OrderPrinter {
	public abstract void printBegin();
	public abstract void printGroupBegin(Customer customer);
	public abstract void printPosition(Order order, Product product, int value);
	public abstract void printGroupEnd(int groupSum);
	public abstract void printEnd(int totalSum);
}
