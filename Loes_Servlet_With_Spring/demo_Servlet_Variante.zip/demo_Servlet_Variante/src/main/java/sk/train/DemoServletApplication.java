package sk.train;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.annotation.Bean;
import sk.train.servlets.HelloServlet;

@SpringBootApplication
//@ServletComponentScan
public class DemoServletApplication {

    public static void main(String[] args) {
        SpringApplication.run(DemoServletApplication.class, args);
    }

    @Bean
    public ServletRegistrationBean<HelloServlet> helloServ(){
        return new ServletRegistrationBean<>(
                new HelloServlet(), "/Hello"
        );
    }

}
