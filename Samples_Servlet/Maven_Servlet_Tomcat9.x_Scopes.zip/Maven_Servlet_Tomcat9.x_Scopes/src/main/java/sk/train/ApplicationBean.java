package sk.train;

public class ApplicationBean {
}
