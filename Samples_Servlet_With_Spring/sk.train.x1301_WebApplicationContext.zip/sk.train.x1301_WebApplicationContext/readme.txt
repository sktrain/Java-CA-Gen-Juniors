Vorsicht: wir sollten dieselbe Java-Version für das Deployment nutzen, unter der auch Tomcat gestartet wird!!
z.B: Tomcat, der prinzipiell mit Java 11 umgehen kann, läuft auf Basis Java 8. Deployment ist Java 11.
Laut Tomcat-Console ist Deployment erfolgreich, funktioniert aber nicht. Leider keine Fehlermeldung!!