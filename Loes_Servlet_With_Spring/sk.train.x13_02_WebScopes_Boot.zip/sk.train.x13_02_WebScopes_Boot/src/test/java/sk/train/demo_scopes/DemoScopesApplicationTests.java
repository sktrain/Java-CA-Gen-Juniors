package sk.train.demo_scopes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoScopesApplicationTests {

	@Test
	void contextLoads() {
	}

}
