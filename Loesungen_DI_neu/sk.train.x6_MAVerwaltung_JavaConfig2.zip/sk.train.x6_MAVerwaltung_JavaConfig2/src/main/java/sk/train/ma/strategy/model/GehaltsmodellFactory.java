package sk.train.ma.strategy.model;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.Properties;

public class GehaltsmodellFactory implements GehaltsmodellFactoryIf {
	
	private Properties props;
	
	
	public GehaltsmodellFactory() {
		props = new Properties();
		try {
			props.load(GehaltsmodellFactory.class.getResourceAsStream("/factory.properties"));
		} catch (IOException e) {
			System.err.println("laden der Properties fehlgeschlagen");
		}
	}
	
	@Override
	public Gehaltsmodell getGehaltsmodell(String type) {

		if (type.equals("A"))
			return new ArbeiterModell(new BigDecimal((int)(Math.random()* Integer.parseInt(props.get("astdlohn").toString()))),
					new BigDecimal(props.get("astdzahl").toString()));
		else return new FixGehaltModell(new BigDecimal((int)(Math.random()* Integer.parseInt(props.get("fgehalt").toString()))));
	}

}
