package appl;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.TableModel;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Application {
	public static void main(String[] args) {
		try (final AnnotationConfigApplicationContext ctx = 
				new AnnotationConfigApplicationContext(ApplConfig.class)) {
			
			TableModel model = ctx.getBean(TableModel.class);
			
			JFrame f = new JFrame();
			JTable mytable = new JTable(model);
			JScrollPane p = new JScrollPane(mytable);
			f.add(p);
			f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			f.pack();
			f.setVisible(true);
			
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			((AbstractTableModel) model).fireTableCellUpdated(0, 1);
			
		}
	}
}
