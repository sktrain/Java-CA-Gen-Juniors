package org.javacream.store.api;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Store")
public class StoreEntity {

    @EmbeddedId
    StoreKey key;

    private int stock;

    public StoreEntity() {
    }

    public StoreEntity(StoreKey key, int stock) {
        this.key = key;
        this.stock = stock;
    }

    public StoreKey getKey() {
        return key;
    }

    public void setKey(StoreKey key) {
        this.key = key;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    @Override
    public String toString() {
        return "StoreEntity{" +
                "key=" + key +
                ", stock=" + stock +
                '}';
    }
}
