package appl;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.dao.DataRetrievalFailureException;
import org.springframework.jdbc.core.JdbcTemplate;

import domain.Account;
import jn.util.DBStatus;

public class Application {
	public static void main(String[] args) {
		
		try (final AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext(ApplConfig.class)) {
			
			final JdbcTemplate template = ctx.getBean(JdbcTemplate.class);
			Connection connection = null;
			try {
				connection = template.getDataSource().getConnection();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			DBStatus.showState(connection, "before");
			demo(template);
			DBStatus.showState(connection, "after");
		}
	}

	private static void demo(final JdbcTemplate template) {
		insertAccount(template, new Account(4711));
		insertAccount(template, new Account(4712));
		final Account account1 = findAccount(template, 4711);
		account1.setBalance(account1.getBalance() + 5000);
		updateAccount(template, account1);
		final Account account2 = findAccount(template, 4712);
		account2.setBalance(account2.getBalance() + 6000);
		updateAccount(template, account2);
		for (final Account account : findAllAccounts(template))
			System.out.println(account);
		deleteAccount(template, account1);
	}

	private static void insertAccount(JdbcTemplate template, Account account) {
		final String sql = "insert into account (number, balance) values (?, ?)";
		final Object result = template.update(sql, account.getNumber(), account.getBalance());
		if ((Integer) result != 1)
			throw new DataRetrievalFailureException(account.toString());
	}

	private static void updateAccount(JdbcTemplate template, Account account) {
		final String sql = "update account set balance = ? where number = ?";
		final Object result = template.update(sql, account.getBalance(), account.getNumber());
		if ((Integer) result != 1)
			throw new DataRetrievalFailureException(account.toString());
	}

	private static void deleteAccount(JdbcTemplate template, Account account) {
		final String sql = "delete from account where number = ?";
		final Object result = template.update(sql, account.getNumber());
		if ((Integer) result != 1)
			throw new DataRetrievalFailureException(account.toString());
	}

	//query ist überladen: aktuelle Variante stellt Parameter-Folge für Varargs um
	private static Account findAccount(JdbcTemplate template, int number) {
		final String sql = "select number, balance from account where number = ?";
		return template.query(sql,  rs -> {
			if (!rs.next())
				return null;
			final Account a = new Account();
			a.setNumber(rs.getInt(1));
			a.setBalance(rs.getInt(2));
			return a;
		}, number);
	}

	//query ist überladen: aktuelle Variante stellt Parameter-Folge für Varargs um
	private static List<Account> findAllAccounts(JdbcTemplate template) {
		final String sql = "select number, balance from account";
		return template.query(sql,  rs -> {
			final List<Account> list = new ArrayList<>();
			while (rs.next()) {
				final Account a = new Account();
				a.setNumber(rs.getInt(1));
				a.setBalance(rs.getInt(2));
				list.add(a);
			}
			return list;
		});
	}
}
