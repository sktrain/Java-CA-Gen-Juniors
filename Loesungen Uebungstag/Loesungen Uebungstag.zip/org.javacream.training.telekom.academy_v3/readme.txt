Jetzt alles auf unsere Datenbank umgestellt und POM aktualisiert
und damit auch die Tests von JUnit4 auf Jupiter.
Das spezielle Test-Profil wird nicht mehr benötigt.
