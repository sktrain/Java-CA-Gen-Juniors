package sk.train;

import javax.jws.WebService;

@WebService
public interface WsServiceIF {

    public String hello(String name);

    public String register(Student student);
}
