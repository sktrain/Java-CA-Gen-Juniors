package sk.train;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoDependenciesWithProxyApplicationTests {

    @Test
    void contextLoads() {
    }

}
