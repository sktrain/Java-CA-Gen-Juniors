package sk.train.repositories;

import model.Department;
import model.Employee;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface DepRepository extends JpaRepository<Department, Long> {

    //"SELECT u FROM Employee AS u JOIN FETCH u.phones WHERE u.id=:id"
    //Join-Fetch-Variante kann grundsätzlich bei jeder Lazy-Beziehung eingesetzt werden
    @Query("SELECT d FROM Department d JOIN FETCH d.employees WHERE d.departmentId = ?1")
    public abstract Optional<Department> getDepartmentWithEmps(long id) ;



    //Fetching Eager per Entity Graph
    @EntityGraph(attributePaths = { "employees" })
    @Query("SELECT d FROM Department d WHERE d.departmentId = ?1")
    public abstract Optional<Department> getDepartmentWithEmpsByGraph(long id);

}
