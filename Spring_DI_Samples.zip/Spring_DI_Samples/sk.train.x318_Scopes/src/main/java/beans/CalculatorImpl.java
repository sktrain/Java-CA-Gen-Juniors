package beans;

import ifaces.Calculator;

public class CalculatorImpl implements Calculator {
	private int value;
	public CalculatorImpl() {

	}
	public void add(int value) {
		this.value += value;
	}
	public void subtract(int value) {
		this.value -= value;
	}
	public int getValue() {
		return this.value;
	}
}
