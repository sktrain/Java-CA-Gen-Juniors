package sk.train;

import javax.jws.WebService;

@WebService(endpointInterface = "sk.train.WsServiceIF")
public class WsServiceImpl implements WsServiceIF {
    private int counter;

    public String hello(String name) {
        return "Hello " + name + "!";
    }

    public String register(Student student) {
        counter++;
        return student.getName() + " is registered student number " + counter;
    }
}