package org.javacream.web;

import org.javacream.books.warehouse.api.Book;
import org.javacream.books.warehouse.api.BookException;
import org.javacream.books.warehouse.api.BooksService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping(path = "books")
public class BookController {

    @Autowired
    BooksService repo;

    @GetMapping("/{id}")
    public Book bookById(@PathVariable("id") String id) throws BookException {
        Book b = repo.findBookByIsbn(id);
        return b;
    }


    @GetMapping
    public Collection<Book> allBooks() {
        System.err.println(repo.findAllBooks().getClass());
        return repo.findAllBooks();
    }

    @PostMapping
    public String saveBook(@RequestBody Book book) throws BookException {
        //repo.findBookByIsbn(book.getIsbn()) ;
        System.err.println(book);
        return repo.newBook(book.getTitle(), book.getPrice(), new HashMap<String, Object>());
    }

    @PutMapping
    public Book updateBook(@RequestBody Book book) throws BookException {
        return repo.updateBook(book);
    }

    @DeleteMapping("/{id}")
    public void deleteBook(@PathVariable("id") String id) throws BookException {
        repo.deleteBookByIsbn(id);
    }


}
