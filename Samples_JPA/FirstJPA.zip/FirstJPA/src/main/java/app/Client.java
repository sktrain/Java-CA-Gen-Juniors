package app;

import model.Person;

import javax.persistence.*;
import java.time.LocalDate;

public class Client {

    public static void main(String[] args) throws InterruptedException {

        EntityManagerFactory emf = Persistence.createEntityManagerFactory("test");
        EntityManager em = emf.createEntityManager();

        Person p = new Person(2, "Karrer", LocalDate.now());

        //Create
        EntityTransaction et = em.getTransaction();
        et.begin();
        em.persist(p);
        et.commit();

        //Read
        Person p1 = em.find(Person.class, 2);
        System.out.println(p1);
        System.out.println(p1 == p);

        //Update
        et = em.getTransaction();
        et.begin();
        System.out.println(em.contains(p));
        p.setName("Mustermann");
        et.commit();

        //Update per merge
        Person p2 = new Person(1, "Musterfrau", LocalDate.of(2020, 1, 1));
        et = em.getTransaction();
        et.begin();
        System.out.println(em.contains(p2));
        Person p3 = em.merge(p2);
        System.out.println(p2 == p3);
        et.commit();

        TypedQuery<Person> query = em.createQuery("SELECT p FROM Person p", Person.class);
        query.getResultList().forEach(System.out::println);

        Thread.sleep(60_000);

        //Delete
        et = em.getTransaction();
        et.begin();
        System.out.println(em.contains(p));
        em.remove(p);
        et.commit();


    }
}
