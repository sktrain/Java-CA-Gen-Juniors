package sk.train;

import javax.jws.WebService;

@WebService
public interface HelloIF {
    public String hello(String in);

}
