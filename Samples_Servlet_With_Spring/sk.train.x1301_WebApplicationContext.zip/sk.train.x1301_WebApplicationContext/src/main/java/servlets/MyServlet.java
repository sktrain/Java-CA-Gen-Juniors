package servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.context.ContextLoader;
import org.springframework.web.context.WebApplicationContext;

import beans.MessageBean;
import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;

public class MyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;


	//with programmatic registration possible: context by constructor
	private WebApplicationContext rootContext;

	public MyServlet(AnnotationConfigWebApplicationContext rootContext) {
		this.rootContext = rootContext;
	}

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response)
		throws IOException, ServletException {
		
		response.setContentType("text/plain");
		final PrintWriter out = response.getWriter();

		final HttpSession session = request.getSession();
		final ServletContext servletContext = session.getServletContext();
		final String applContextName = WebApplicationContext.ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE;
		final WebApplicationContext ctx1 = (WebApplicationContext)servletContext.getAttribute(applContextName);
		
		final WebApplicationContext ctx2 = ContextLoader.getCurrentWebApplicationContext();
		
		out.println(ctx1 == ctx2);
		out.println(ctx1 == rootContext);

		final MessageBean bean = ctx1.getBean(MessageBean.class);
		out.println(bean.getMessage());
		out.println(servletContext.getAttribute("messageBean"));
	}
}
