package appl;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import processor.GroupChangeProcessor;


public class Application {
	public static void main(String[] args) {
		//Context anhand Component-Scan f�r Package "processor.impl"
		try (AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext("processor.impl")) {
			GroupChangeProcessor p = (GroupChangeProcessor) ctx.getBean("gcp");
			p.run();
		}
	}
}
