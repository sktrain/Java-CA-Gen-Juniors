package sk.train.demo_scopes;

import org.springframework.boot.web.servlet.context.ServletWebServerApplicationContext;
import org.springframework.web.context.WebApplicationContext;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

public class MyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	//with programmatic registration possible: context by constructor
	private WebApplicationContext rootContext;

	public MyServlet(ServletWebServerApplicationContext rootContext) {
		this.rootContext = rootContext;
	}

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response)
		throws IOException, ServletException {

		response.setContentType("text/plain");
		final PrintWriter out = response.getWriter();

		out.println(rootContext.getBean("requestBean"));
		out.println(rootContext.getBean("sessionBean"));
		out.println(rootContext.getBean("applicationBean"));
		out.println(rootContext.getBean("singletonBean"));
		out.println();
		out.println(request.getAttribute("requestBean"));
		out.println(request.getSession().getAttribute("sessionBean"));
		out.println(request.getSession().getServletContext().getAttribute("applicationBean"));
		out.println(request.getSession().getServletContext().getAttribute("singletonBean"));
	}
}
