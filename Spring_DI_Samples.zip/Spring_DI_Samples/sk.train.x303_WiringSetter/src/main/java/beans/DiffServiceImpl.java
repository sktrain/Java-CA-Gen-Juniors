package beans;

import ifaces.DiffService;
import jn.util.Log;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DiffServiceImpl implements DiffService {

	private static Logger logger = LoggerFactory.getLogger("sk.train");
	public DiffServiceImpl() {
		Log.log();
		logger.info("Konstruktor {}", this.getClass());
	}
	@Override
	public int diff(int x, int y) {
		return x - y;
	}
}
