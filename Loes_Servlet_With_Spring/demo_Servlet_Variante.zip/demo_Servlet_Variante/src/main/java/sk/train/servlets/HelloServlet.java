package sk.train.servlets;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.Writer;
import java.util.Enumeration;

//@WebServlet("/karrer/hallo")
public class HelloServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Writer writer = resp.getWriter();
        writer.append("Served at: ").append(req.getRequestURL());
        Enumeration<String> headers = req.getHeaderNames();
        while (headers.hasMoreElements()){
            writer.append("\n");
            String headername = headers.nextElement();
            writer.append(headername + " = " + req.getHeader(headername));
        };

    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req, resp);
    }
}
