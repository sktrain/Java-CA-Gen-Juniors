package servlets;

import beans.ApplicationBean;
import beans.RequestBean;
import beans.SessionBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.springframework.web.context.WebApplicationContext;

@Configuration
public class AppConfig {

    @Bean(name ="requestBean")
    @Scope(WebApplicationContext.SCOPE_REQUEST)
    public RequestBean requestBean() {
        return new RequestBean(sessionBean());
    }

    @Bean(name ="sessionBean")
    @Scope(WebApplicationContext.SCOPE_SESSION)
    public SessionBean sessionBean() {
        return new SessionBean(applicationBean());
    }

    @Bean(name ="applicationBean")
    @Scope(WebApplicationContext.SCOPE_APPLICATION)
    public ApplicationBean applicationBean() {
        return new ApplicationBean();
    }

}
