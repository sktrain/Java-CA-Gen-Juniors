Ein Spring Boot Servlet Projekt,
aber statt mit Annotations im Code (@WebServlet, @ServletComponentScan)
mit Verwendung einer ServletRegistrationBean.


Port des Embbedded Tomcat ist vorsichtshalber auf "8888" gesetzt.
(siehe application.properties)