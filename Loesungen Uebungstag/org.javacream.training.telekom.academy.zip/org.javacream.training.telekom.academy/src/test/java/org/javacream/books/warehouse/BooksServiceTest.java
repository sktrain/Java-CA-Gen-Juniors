package org.javacream.books.warehouse;


import java.util.Collection;
import java.util.HashMap;

import org.javacream.util.Ordering;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.fail;

public class BooksServiceTest {

	private MapBooksService booksService;
	private String ISBN;

	private static final String WRONG_ISBN = "##ISBN##";
	private static final double PRICE = 9.99;

	@BeforeEach
	public void init() {
		booksService = new MapBooksService();
		try {
			ISBN = booksService.newBook("TEST", PRICE, new HashMap<String, Object>());
		} catch (BookException e) {
			throw new RuntimeException(e.getMessage());
		}

	}

	@Test
	public void testBooksSequence() {
		doTest(booksService);
	}

	@Test
	public void deleteBookByIsbnOk() throws BookException {
		Book book = booksService.findBookByIsbn(ISBN);
		booksService.deleteBookByIsbn(ISBN);
		Assertions.assertFalse(booksService.findAllBooks().contains(book));
	}

	@Test
	public void deleteBookByIsbnWrong() throws BookException {
		Assertions.assertThrows(BookException.class, () -> booksService.deleteBookByIsbn(WRONG_ISBN));
	}

	@Test
	public void findBookByIsbnOk() throws BookException {
		Book book = booksService.findBookByIsbn(ISBN);
		Assertions.assertNotNull(book);
	}

	@Test
	public void findBookByIsbnWrong() throws BookException {
		Assertions.assertThrows(BookException.class, () -> booksService.findBookByIsbn(WRONG_ISBN));
	}

	@Test
	public void findBookAllBooks() {
		Assertions.assertNotNull(booksService.findAllBooks());
	}

	@Test
	public void updateBookOk() throws BookException {
		final String NEW_TITLE = "CHANGED";
		Book book = booksService.findBookByIsbn(ISBN);
		book.setTitle(NEW_TITLE);
		book.setPrice(19.99);
		Book book2 = booksService.updateBook(book);
		Assertions.assertTrue(NEW_TITLE.equals(book2.getTitle()));
	}

	@Test
	public void updateBookWrong() throws BookException {
		Book book = new Book();
		book.setIsbn(WRONG_ISBN);
		book.setPrice(19.99);
		Assertions.assertThrows(Exception.class, () -> booksService.updateBook(book));
	}

	@Test
	public void updateBookPriceNotGreaterZeroFails() throws BookException {
		Book book = booksService.findBookByIsbn(ISBN);
		book.setPrice(-19.99);
		Assertions.assertThrows(Exception.class, () -> booksService.updateBook(book));
	}

	@Test
	public void createBook() throws BookException {
		String isbn = booksService.newBook("TEST", PRICE, new HashMap<String, Object>());
		Book book = booksService.findBookByIsbn(isbn);
		Assertions.assertTrue(book.getClass() == Book.class);

	}

	@Test
	public void createSchoolBook() throws BookException {
		HashMap<String, Object> options = new HashMap<String, Object>();
		options.put("subject", "Physics");
		options.put("year", 10);
		String isbn = booksService.newBook("TEST", PRICE, options);
		Book book = booksService.findBookByIsbn(isbn);
		Assertions.assertTrue(book.getClass() == SchoolBook.class);

	}

	@Test
	public void createSpecialistBook() throws BookException {
		HashMap<String, Object> options = new HashMap<String, Object>();
		options.put("topic", "Very Special");
		String isbn = booksService.newBook("TEST", PRICE, options);
		Book book = booksService.findBookByIsbn(isbn);
		Assertions.assertTrue(book.getClass() == SpecialistBook.class);

	}

	@Test
	public void createBookFailsNullOptions() throws BookException {
		Assertions.assertThrows(Exception.class, () -> booksService.newBook("TEST", PRICE, null));

	}

	private void doTest(MapBooksService booksService) {

		try {
			Collection<Book> books = booksService.findAllBooks();
			final int startSize = books.size();
			String j2eeTitle = "Spring";
			String isbn = booksService.newBook(j2eeTitle, PRICE, new HashMap<String, Object>());
			books = booksService.findAllBooks();
			final int endSize = books.size();
			Assertions.assertTrue(endSize == startSize + 1);
			Assertions.assertNotNull(isbn);
			Assertions.assertNotNull(booksService.findBookByIsbn(isbn));

			try {
				booksService.findBookByIsbn("ISBN-3");
				fail("BookException must be thrown!");
			} catch (BookException e) {
				// OK
			}
			booksService.deleteBookByIsbn(isbn);
			Assertions.assertTrue(startSize == booksService.findAllBooks().size());
			try {
				booksService.deleteBookByIsbn(isbn);
				fail("BookException must be thrown!");
			} catch (BookException e) {
				// OK
			}

		} catch (BookException bookException) {
			bookException.printStackTrace();
			fail(bookException.getMessage());
		}

	}

	@Test
	public void listBooks() {
		Assertions.assertNotNull(booksService.booksList());
	}

	@Test
	public void listBooksAscending() {
		Assertions.assertNotNull(booksService.booksList(Ordering.ASCENDING));
	}

	@Test
	public void listBooksDescending() {
		Assertions.assertNotNull(booksService.booksList(Ordering.DESCENDING));
	}
	@Test
	public void listBooksPriceRange() {
		Assertions.assertNotNull(booksService.findBooksByPriceRange(12.5, 33.40));
	}

}
