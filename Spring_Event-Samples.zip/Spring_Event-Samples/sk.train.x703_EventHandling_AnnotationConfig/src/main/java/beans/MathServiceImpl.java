package beans;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import ifaces.MathService;
import jn.util.Log;

@Service
public class MathServiceImpl implements MathService {

	@PostConstruct
	private void postConstruct() {
		Log.log2();
	}
	
	@PreDestroy
	private void preDestroy() {
		Log.log2();
	}
	
	@Override
	public int sum(int x, int y) {
		Log.log2(x, y);
		return x + y;
	}

	@Override
	public int diff(int x, int y) {
		return x - y;
	}
}
