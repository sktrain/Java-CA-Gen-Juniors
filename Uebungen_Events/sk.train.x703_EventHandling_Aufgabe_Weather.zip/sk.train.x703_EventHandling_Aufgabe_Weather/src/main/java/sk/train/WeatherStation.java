package sk.train;


import java.util.ArrayList;

//dies soll das Observable sein
public class WeatherStation implements Observable {

	private WeatherData weatherData;
	private ArrayList<Observer> observers;
	
	
	public WeatherStation() {
		observers = new ArrayList();
	}
	
	public void registerObserver(Observer o) {
		observers.add(o);
	}
	
	public void removeObserver(Observer o) {
		int i = observers.indexOf(o);
		if (i >= 0) {
			observers.remove(i);
		}
	}


	public void changeWeather(WeatherData weatherData) {
		this.weatherData = weatherData;
		notifyObservers(weatherData);
	}
	
	public void notifyObservers(WeatherData weatherData) {
		for (int i = 0; i < observers.size(); i++) {
			Observer observer = observers.get(i);
			observer.update(weatherData);
		}
	}	
	
}
