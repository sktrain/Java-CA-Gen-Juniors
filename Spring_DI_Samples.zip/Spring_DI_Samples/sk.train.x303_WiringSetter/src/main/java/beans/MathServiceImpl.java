package beans;

import ifaces.DiffService;
import ifaces.MathService;
import ifaces.SumService;
import jn.util.Log;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MathServiceImpl implements MathService {

	private static Logger logger = LoggerFactory.getLogger("sk.train");
	
	private SumService sumService;
	private DiffService diffService;
	
	public MathServiceImpl() { 
		Log.log();
		logger.info("Konstruktor {}", this.getClass());
	}

	public void setSumService(SumService sumService) { // must(!) be public
		Log.log(sumService);
		logger.info("sumService: {}", sumService);
		this.sumService = sumService;
	}
	
	public void setDiffService(DiffService diffService) { // must(!) be public
		Log.log(diffService);
		logger.info("diffService: {}", diffService);
		this.diffService = diffService;
	}

	@Override
	public int sum(int x, int y) {
		return this.sumService.sum(x, y);
	}

	@Override
	public int diff(int x, int y) {
		return this.diffService.diff(x, y);
	}
}
