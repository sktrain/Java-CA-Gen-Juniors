package beans;

import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Service;

import appl.ExitEvent;
import ifaces.MathService;
import jn.util.Log;

@Service
public class MathServiceImpl implements MathService {
	
	//ApplicationContextAware
	@Autowired
	private ApplicationContext ctx;
	
	@PreDestroy
	private void preDestroy() {
		Log.log();
		//Feuern des ExitEvents
		ctx.publishEvent(new ExitEvent(this));
	}
	
	@Override
	public int sum(int x, int y) {
		return x + y;
	}

	@Override
	public int diff(int x, int y) {
		return x - y;
	}
}
