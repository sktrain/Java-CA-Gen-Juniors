package beans;

import ifaces.SumService;
import jn.util.Log;

public class SumServiceImplRecursive implements SumService {
	public SumServiceImplRecursive() { 
		Log.log();
	}
	@Override
	public int sum(int x, int y) {
		return y == 0 ? x : 1 + sum(x, y - 1);
	}
}
