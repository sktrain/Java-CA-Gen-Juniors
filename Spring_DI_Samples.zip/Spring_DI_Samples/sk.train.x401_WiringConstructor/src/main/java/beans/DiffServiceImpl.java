package beans;

import org.springframework.stereotype.Service;

import ifaces.DiffService;
import jn.util.Log;

//@Component
@Service
public class DiffServiceImpl implements DiffService {
	public DiffServiceImpl() {  
		Log.log();
	}
	@Override
	public int diff(int x, int y) {
		return x - y;
	}
}
