package sk.train;

public interface Observer {
	public void update(WeatherData weatherData);
}
