Web-Projekt mit Spring-Security mit expliziter InMemory-Konfiguration
und Anpassung der Login-Seite. Funktioniert allerdings noch nicht richtig

Basiert auf sk.train.x14_04_JPA_Rest_SOAP_Boot_Solution

(Rest mit JPA, Spring Boot und XML-MessageFormat mit Jackson
+ zusätzlich als SOAP-WS mit CXF aufrufbar! (http://localhost:8088/services/jaxwsemployee?wsdl)

Dazu sind weitere Bibliotheken im ClassPath nötig, insbesondere der CXF-Starter.
Autowiring des Repos in den WebService ist nur möglich, falls dieser durch Spring gemanaged ist (Spring-Bean).

Hier jetzt mit getrennten Controller-Klassen für XML und JSON. 
Fehler kommen allerdings mal im JSON-Format und mal im XML-Format.)

