package servlets;

import beans.ApplicationBean;
import beans.RequestBean;
import beans.SessionBean;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

public class MyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	//with programmatic registration possible: context by constructor
	private final WebApplicationContext rootContext;

	public MyServlet(AnnotationConfigWebApplicationContext rootContext) {
		this.rootContext = rootContext;
	}

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response)
		throws IOException, ServletException {

		response.setContentType("text/plain");
		final PrintWriter out = response.getWriter();

		final ApplicationBean applicationBean = rootContext.getBean(ApplicationBean.class);
		final SessionBean sessionBean = rootContext.getBean(SessionBean.class);
		final RequestBean requestBean = rootContext.getBean(RequestBean.class);

		out.println("applicationBean");
		out.println("\t" + applicationBean);
		out.println("\t" + ServletUtils.identityOf(applicationBean));

		out.println("applicationBean.getSessionBean()");
		out.println("\t" + applicationBean.getSessionBean());
		out.println("\t" + ServletUtils.identityOf(applicationBean.getSessionBean()));

		out.println("sessionBean");
		out.println("\t" + sessionBean);
		out.println("\t" + ServletUtils.identityOf(sessionBean));

		out.println("sessionBean.getRequestBean()");
		out.println("\t" + sessionBean.getRequestBean());
		out.println("\t" + ServletUtils.identityOf(sessionBean.getRequestBean()));

		out.println("requestBean");
		out.println("\t" + requestBean);
		out.println("\t" + ServletUtils.identityOf(requestBean));

		ServletUtils.printScopes(System.out, request, (k, v) -> k.contains("Bean"));
	}
}
