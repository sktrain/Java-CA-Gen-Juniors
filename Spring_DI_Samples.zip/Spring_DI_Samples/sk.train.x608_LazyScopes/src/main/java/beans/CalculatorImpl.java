package beans;

import ifaces.Calculator;
import jn.util.Log;

public class CalculatorImpl implements Calculator {
	private int value;
	public CalculatorImpl() {
		Log.log();
	}
	@Override
	public void add(int value) {
		this.value += value;
	}
	@Override
	public void subtract(int value) {
		this.value -= value;
	}
	@Override
	public int getValue() {
		return this.value;
	}
}
