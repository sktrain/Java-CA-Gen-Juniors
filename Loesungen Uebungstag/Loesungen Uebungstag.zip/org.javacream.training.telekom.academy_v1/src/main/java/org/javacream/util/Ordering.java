package org.javacream.util;

public enum Ordering {
	NONE, ASCENDING, DESCENDING;
}
