JPA durch Spring gemanaged + deklarative Transaktionsunterstützung

+ Repository-Generierung (Vorsicht: Namensabhängigkeit zur EntityManagerFactory (default), siehe API-Doc zu
org.springframework.data.jpa.repository.config.EnableJpaRepositories)

Es wird weitere Dependency benötigt:
<!-- for repository generation -->
		<dependency>
			<groupId>org.springframework.data</groupId>
			<artifactId>spring-data-jpa</artifactId>
			<version>2.6.0</version>
		</dependency>