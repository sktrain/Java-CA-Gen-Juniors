package org.javacream.store.impl;

import org.javacream.store.api.StoreEntity;
import org.javacream.store.api.StoreKey;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;


public interface StoreRepo extends JpaRepository<StoreEntity, StoreKey> {
    @Query(value = "select stock from Store where category = :category and id = :id", nativeQuery = true)
    public Integer getStock(@Param("category") String category, @Param("id") String id);
}
