package org.javacream.books.warehouse.impl;

import org.javacream.books.warehouse.api.Book;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface BookRepo extends JpaRepository<Book, String> {

    List<Book> findBooksByPriceBetweenOrderByIsbn(double minprice, double maxprice);



    @Query(value = "select * from Book where REGEXP_LIKE(title , :pattern)", nativeQuery = true)
    List<Book> getBooksForMatch(@Param("pattern") String pattern);

}
