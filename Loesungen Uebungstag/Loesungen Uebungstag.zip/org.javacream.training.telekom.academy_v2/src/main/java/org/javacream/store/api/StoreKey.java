package org.javacream.store.api;

import javax.persistence.Embeddable;
import java.io.Serializable;
import java.util.Objects;

@Embeddable
public class StoreKey implements Serializable {

    private String category;

    private String id;

    public StoreKey() {
    }

    public StoreKey(String category, String id) {
        this.category = category;
        this.id = id;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        StoreKey storeKey = (StoreKey) o;
        return Objects.equals(category, storeKey.category) && Objects.equals(id, storeKey.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(category, id);
    }

    @Override
    public String toString() {
        return "StoreKey{" +
                "category='" + category + '\'' +
                ", id='" + id + '\'' +
                '}';
    }
}
