package beans;

public class MessageBean {
	public String getMessage() {
		return this.toString();
	}
}
