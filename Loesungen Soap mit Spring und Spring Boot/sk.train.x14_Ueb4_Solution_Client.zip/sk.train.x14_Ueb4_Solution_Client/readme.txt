Ein erstes Servlet Maven Projekt mit aktuellen Plugin-Versionen vom Januar 2023
    + Jupiter-Dependencies
    + Servlet-Dependencies

+ Ergänzung: Loesung zu Uebung 2: CXF mit Spring Client Seite

