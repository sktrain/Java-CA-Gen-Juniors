package app;

import app.model.Employee;

import javax.jws.WebService;
import java.util.List;

@WebService
public interface WSImplementorIF {
    List<Employee> allEmps();

    Employee saveEmp(Employee emp);

    Employee empById(Long id);
}
