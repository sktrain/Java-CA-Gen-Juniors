package sk.train.demoRest;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.io.InputStream;
import java.io.Writer;
import java.util.Enumeration;

@RestController
public class RestApp {

    @GetMapping("/analyze")
    public String analyze(HttpServletRequest request){
        StringBuilder sb = new StringBuilder("Das teilt uns der Client mit:\n");
        sb.append("Served at: ").append(request.getRequestURL());
        sb.append("\n");
        sb.append("requestURI = " + request.getRequestURI());
        Enumeration<String> headers = request.getHeaderNames();
        while (headers.hasMoreElements()){
            sb.append("\n");
            String headername = headers.nextElement();
            sb.append(headername + " = " + request.getHeader(headername));
        };
        sb.append("\n");
        sb.append("method = " + request.getMethod());
        sb.append("\n");
        sb.append("authType = " + request.getAuthType());
        sb.append("\n");
        sb.append("queryString = " + request.getQueryString());
        sb.append("\n");
        sb.append("remotePort = " + request.getRemotePort());
        sb.append("\n");
        sb.append("remoteHost = " + request.getRemoteHost());
        sb.append("\n");
        sb.append("protocol = " + request.getProtocol());

        return sb.toString();
    }



}
