package sk.train.servlets;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.util.Enumeration;
import java.util.function.BiPredicate;
import java.util.function.Function;
import java.util.function.Supplier;

public class ServletUtils {

	public static String identityOf(Object obj) {
		return obj.getClass().getSimpleName() + " (" + Integer.toHexString(System.identityHashCode(obj)) + ")";
	}

	public static void printScopes(PrintStream out, HttpServletRequest request, BiPredicate<String, Object> filter) {
		printScopes(new PrintWriter(out, true), request, filter);
	}
	
	public static void printScopes(PrintWriter out, HttpServletRequest request, BiPredicate<String, Object> filter) {
		out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
		final HttpSession httpSession = request.getSession();
		final ServletContext servletContext = httpSession.getServletContext();
		printScope(out, "Application-Scope", servletContext::getAttributeNames,
				servletContext::getAttribute, filter);
		printScope(out, "Session-Scope", httpSession::getAttributeNames, httpSession::getAttribute, filter);
		printScope(out, "Request-Scope", request::getAttributeNames, request::getAttribute, filter);
		out.println("<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<");
	}

	private static void printScope(PrintWriter out, String contextName, Supplier<Enumeration<?>> supplier,
			Function<String, Object> lookup, BiPredicate<String, Object> filter) {
		out.println(contextName);
		final Enumeration<?> names = supplier.get();
		while (names.hasMoreElements()) {
			final String name = (String) names.nextElement();
			final Object value = lookup.apply(name);
			if (!filter.test(name, value))
				continue;
			out.println("\t" + name + " ==> " + identityOf(value));
		}
	}
}
