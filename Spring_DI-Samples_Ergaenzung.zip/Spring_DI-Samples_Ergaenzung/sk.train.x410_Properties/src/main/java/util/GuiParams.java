package util;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Component
@PropertySource("classpath:gui.properties")
public class GuiParams {
	
	@Value("${title}")
	public String title;
	
	@Value("${x}")
	public int x;
	
	@Value("${y}")
	public int y;
	
	@Value("${width}")
	public int width;
	
	@Value("${height}")
	public int height;

	@Override
	public String toString() {
		return this.getClass().getSimpleName() + 
				" [" + this.title + ", " + this.x + ", " + this.y + ", " + this.width + ", " + this.height + "]";
	}
}
