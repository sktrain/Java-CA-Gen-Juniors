Jetzt alles auf Datenbank (embedded H2) umgestellt (wie in Aufgabe gefordert) und Test aktualisiert.
