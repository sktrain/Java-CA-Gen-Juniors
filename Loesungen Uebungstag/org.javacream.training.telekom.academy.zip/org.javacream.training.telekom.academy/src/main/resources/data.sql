drop table KEYS if exists
create table KEYS (COL_KEY Integer)
insert into KEYS values (10)
