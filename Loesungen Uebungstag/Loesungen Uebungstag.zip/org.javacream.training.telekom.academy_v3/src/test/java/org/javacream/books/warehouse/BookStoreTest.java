package org.javacream.books.warehouse;

import org.javacream.books.warehouse.api.BookException;
import org.javacream.store.impl.JpaStoreService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;


@SpringBootTest
@ActiveProfiles("dev")
public class BookStoreTest {

    @Autowired
    private JpaStoreService storeService;  //da das Interface nur die get-Methode definiert

    @Test  //quasi schon Test für Stock-Speicherung
    public void initialize() throws BookException {
        storeService.setStock("books", "testisbn", 10);
        Assertions.assertEquals(10, storeService.getStock("books", "testisbn"));
    }
}
