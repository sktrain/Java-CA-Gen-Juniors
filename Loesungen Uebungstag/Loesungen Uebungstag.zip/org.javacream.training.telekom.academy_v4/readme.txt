Jetzt alles auf unsere Datenbank umgestellt und POM aktualisiert
und damit auch die Tests von JUnit4 auf Jupiter.
Das spezielle Test-Profil wird nicht mehr benötigt.

Jetzt noch die Sortierung der Datenbank überlassen und nicht mehr
im Hauptspeicher via BookService.
