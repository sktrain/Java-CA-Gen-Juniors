package beans;

import ifaces.DiffService;
import jn.util.Log;

public class DiffServiceImpl implements DiffService {
	public DiffServiceImpl() {  
		Log.log();
	}
	@Override
	public int diff(int x, int y) {
		return x - y;
	}
}
