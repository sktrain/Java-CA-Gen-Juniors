package sk.train;

import javax.annotation.PostConstruct;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.Writer;
import java.util.Enumeration;

@WebServlet("/karrer/scopes")
public class HelloServlet extends HttpServlet {

    private ApplicationBean applicationBean;
    private SessionBean sessionBean;
    private RequestBean requestBean;


    @PostConstruct
    public void initialize()  {
        applicationBean = new ApplicationBean();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        //Request-Scope nutzen
        requestBean = new RequestBean();

        //Session-Scope nutzen
        HttpSession session = req.getSession();
        if (session.isNew()) {
            session.setAttribute("SessionBean", new SessionBean());
        }

        //Application-Scope nutzen
        ServletContext servletContext = this.getServletContext();
        if(servletContext.getAttribute("ApplicationBean") == null) {
            servletContext.setAttribute("ApplicationBean", applicationBean);
        }

        Writer writer = resp.getWriter();
        writer.append("RequestScope: " + requestBean);
        writer.append("\nSessionScope: " + session.getAttribute("SessionBean"));
        writer.append("\nApplicationScope: " + getServletContext().getAttribute("ApplicationBean"));

    }

}
