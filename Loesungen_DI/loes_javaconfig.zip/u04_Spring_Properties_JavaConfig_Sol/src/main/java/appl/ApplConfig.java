package appl;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import processor.Database;
import processor.GroupChangeProcessor;
import processor.OrderPrinter;
import processor.OrderReader;
import processor.impl.DatabaseDummy;
import processor.impl.GroupChangeProcessorImpl;
import processor.impl.SimpleOrderPrinter;
import processor.impl.SimpleOrderReader;

@Configuration
@PropertySource("classpath:order.properties")
public class ApplConfig {
	
	@Value("${filename}")
	private String fname;

	// <bean id="reader" class="processor.impl.SimpleOrderReader">
	// <property name="filename" value="src/orders.txt" />
	// </bean>

	@Bean
	public OrderReader reader() {
		SimpleOrderReader reader = new SimpleOrderReader();
		reader.setFilename(fname);
		return reader;
	}

	// <bean id="database" class="processor.impl.DatabaseDummy" />
	
	@Bean
	public Database database() {
		return new DatabaseDummy();
	}
	
	// <bean id="printer" class="processor.impl.SimpleOrderPrinter" />

	@Bean
	public OrderPrinter printer() {
		return new SimpleOrderPrinter();
	}
	
	
	// <bean id="gcp" class="processor.impl.GroupChangeProcessorImpl">
	// <property name="reader" ref="reader" />
	// <property name="database" ref="database" />
	// <property name="printer" ref="printer" />

	@Bean(name="gcp")	
	public GroupChangeProcessor gproc() {
		GroupChangeProcessorImpl gcp = new GroupChangeProcessorImpl();
		gcp.setDatabase(database());
		gcp.setReader(reader());
		gcp.setPrinter(printer());
		return gcp;
	}

}
