package beans;

public class MathService {
	private final FileLogger logger;
	public MathService(FileLogger logger) {
		this.logger = logger;
	}
	public int sum(int x, int y) {
		this.logger.log("sum(" + x + ", " + y + ")");
		return x + y;
	}
	public int diff(int x, int y) {
		this.logger.log("diff(" + x + ", " + y + ")");
		return x - y;
	}
}
