Servlet-Beispiel mit Hilfe von Intellij (Jakarta EE Web-Applikation):
Tomcat wird dann aus Intellij gestartet und es erfolgt direktes Deployment
durch "run" auf die jsp-Datei.
(Dadurch läuft Tomcat, sofern möglich, mit derselben Java-Version, die auch das
Intellij-Projekt nutzt.)
Dazu muss der Pfad zum Tomcat-Home angegeben werden.
Anwendung besteht aus einer JSP-Seite und Hello-Applet.
(Deployment wird in der Management-Console des Tomcat angezeigt,
dort finden wir auch den URL.)