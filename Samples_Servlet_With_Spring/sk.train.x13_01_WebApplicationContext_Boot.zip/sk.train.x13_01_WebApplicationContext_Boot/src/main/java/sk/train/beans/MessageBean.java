package sk.train.beans;

public class MessageBean {
	public String getMessage() {
		return this.toString();
	}
}
