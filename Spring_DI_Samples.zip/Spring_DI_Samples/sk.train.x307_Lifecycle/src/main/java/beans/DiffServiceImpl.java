package beans;

import ifaces.DiffService;


public class DiffServiceImpl implements DiffService {
	public void postConstruct() {
		System.out.println("PostConstruct");
	}
	public void preDestroy() {
		System.out.println("PreDestroy");
	}
	public DiffServiceImpl() {  

	}
	@Override
	public int diff(int x, int y) {
		return x - y;
	}
}
