Rest-Frontend gemäß Aufgabe auf Basis des vorhandenen Codes für den Schritt: Umstellung auf Spring Boot und Nutzung von JPA
https://github.com/Integrata-Cegos/Telekom_AgileAcademy/tree/06-07-Datenbankzugriff


- An jedem RestController sollte @RequestMapping angegeben werden, um eine eindeutige Zuordnung von Controller und Methode
zu erreichen (@Value gibt der Controllerbohne einen Namen und ist nicht die Pfadzuordnung!)

- Jackson als JSON-Provider kommt sowohl mit der Book-Klasse als auch der Collection<Book> bei den REST-Methoden klar

- Der vorhandene Code des ISBN-Generators kann nur funktionieren, wenn vorab die Tabelle existiert und ein Startwert
in der Tabelle vorhanden ist. Da der ISBN-Generator auch beim Erzeugen eines neuen Book benutzt wird, kann auch das
nur unter dieser Voraussetzung funktionieren. Sofern hier laut Aufgabe kein Entity-Ansatz gewählt werden soll, kann
diese Tabelle nicht mittels JPA/Hibernate generiert werden.  2 Lösungen bieten sich an:
    1) Wir erzeugen die Tabelle + Startwert via Skript "data.sql", das durch SpringBoot automatisch beim Start der Anwendung
    aufgerufen wird. Dazu muss die Property "spring.sql.init.mode=always" bei Verwendung einer vorhandenen Datenbank
    gesetzt werden.
    Falls wir zusätzlich mittels der Property "debug=true" den Debug-Level von SpringBoot aktivieren, kann man unter
    anderem auch die Ausführung des Skripts nachvollziehen!
    2) Wir erzeugen die Tabelle + Startwert via "PostConstruct"-Methode im ISBN-Generator (siehe auskommentierten Code).
    Das funktioniert aber nicht via dem injizierten EntityManager, da dieser für DDL- und DML-Anweisungen eine Transaktion
    benötigt. Die kann aber nicht mehr per Hand via "getTransction"-Methode genutzt werden, da es sich um den durch Spring
    bereit gestellten Proxy handelt, der den "PlatformTransactionManager" von Spring voraussetzt, z.B. via "@Transactional"
    Eine "PostConstruct"-Methode kann aber leider nicht zusätzlich mit "@Transactional" einen Proxy verpasst bekommen
    (knirscht beim Start der Anwendung).
    Somit wird das mittels des injizierten JdbcTemplate gemacht, welches erstmal den Autocommit-Modus beibehält!



