package sk.train;

import javax.jws.WebService;

@WebService(endpointInterface = "sk.train.HelloIF")
public class HelloImpl //implements HelloIF
{
   public String hello(String in) {
        return "Hallo " + in;
    }
}
