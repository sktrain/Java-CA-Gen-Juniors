package servlets;

import javax.servlet.ServletContext;
import javax.servlet.ServletRegistration;

import org.springframework.web.WebApplicationInitializer;
import org.springframework.web.context.ContextLoaderListener;
import org.springframework.web.context.request.RequestContextListener;
import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;

public class MyWebApplicationInitializer implements WebApplicationInitializer {

	@Override
	public void onStartup(ServletContext servletContext) {
		// Create the 'root' Spring application context
		AnnotationConfigWebApplicationContext rootContext =
				new AnnotationConfigWebApplicationContext();
		rootContext.register(AppConfig.class);

		// Manage the lifecycle of the root application context (context is now application scoped)
		servletContext.addListener(new ContextLoaderListener(rootContext));

		// exposes the request to the current thread
		servletContext.addListener(new RequestContextListener());

		// Register and map the servlet
		ServletRegistration.Dynamic servlet =
				servletContext.addServlet("servlet", new MyServlet(rootContext));
		servlet.setLoadOnStartup(1);  //eager with priority 1
		servlet.addMapping("/");
	}

}