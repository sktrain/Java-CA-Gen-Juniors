Ein HelloWorld Standalone JAX-WS Projekt auf Basis  eines
Maven Projekt mit aktuellen Plugin-Versionen vom Januar 2023
        + Jupiter-Dependencies
        + Metro-Dependencies in der Version 2.x (Jakarta EE8)
        (da ab Java 11 nicht mehr Teil der SE)
Die Metro-Implementierung verursacht einen illegalen reflektiven Zugriff,
der übersteuert werden muss (Java 17).