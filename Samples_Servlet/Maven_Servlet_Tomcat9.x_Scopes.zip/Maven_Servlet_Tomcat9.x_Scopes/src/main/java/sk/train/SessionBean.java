package sk.train;

public class SessionBean {
}
