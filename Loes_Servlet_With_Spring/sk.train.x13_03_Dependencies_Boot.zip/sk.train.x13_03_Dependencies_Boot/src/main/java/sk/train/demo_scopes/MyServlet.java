package sk.train.demo_scopes;

import org.springframework.boot.web.servlet.context.ServletWebServerApplicationContext;
import org.springframework.web.context.WebApplicationContext;
import sk.train.demo_scopes.beans.ApplicationBean;
import sk.train.demo_scopes.beans.RequestBean;
import sk.train.demo_scopes.beans.SessionBean;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

public class MyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private WebApplicationContext rootContext;

	public MyServlet(ServletWebServerApplicationContext rootContext) {
		this.rootContext = rootContext;
	}


	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {

		response.setContentType("text/plain");
		final PrintWriter out = response.getWriter();

		final ApplicationBean appliationBean = rootContext.getBean(ApplicationBean.class);
		final SessionBean sessionBean = rootContext.getBean(SessionBean.class);
		final RequestBean requestBean = rootContext.getBean(RequestBean.class);

		out.println(appliationBean);
		out.println();

		out.println(sessionBean);
		out.println(sessionBean.getApplicationBean());
		out.println();

		out.println(requestBean);
		out.println(requestBean.getSessionBean());
		out.println(requestBean.getSessionBean().getApplicationBean());

		ServletUtils.printScopes(System.out, request, (k, v) -> k.contains("Bean"));
	}
}
