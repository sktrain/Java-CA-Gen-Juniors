package org.javacream.web;

import org.javacream.store.api.StoreService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(value = "/store")
public class StoreController {

    @Autowired
    private StoreService storeService;


    @GetMapping("/{category}/{id}")
    public int getStock(@PathVariable("category") String category, @PathVariable("id") String id){
        return (storeService.getStock(category, id));
    }

    @PostMapping("/{category}/{id}/{stock}")
    public void setStock(@PathVariable("category") String category, @PathVariable("id") String id, @PathVariable("stock") int stock){
        storeService.setStock(category, id, stock);
    }


}
