package advices;


import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;

import jn.util.JoinPointTrace;

@Aspect
public class TraceAdvices {
	@Before("within(beans..*)")
	public void before(JoinPoint joinPoint) {
		JoinPointTrace.trace(">> ", joinPoint, null);
	}
	
	@After("within(beans..*)")
	public void after(JoinPoint joinPoint) {
		JoinPointTrace.trace("<< ", joinPoint, null);
	}
}
