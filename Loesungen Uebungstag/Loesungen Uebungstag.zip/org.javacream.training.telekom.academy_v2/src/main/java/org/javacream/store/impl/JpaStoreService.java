package org.javacream.store.impl;

import org.javacream.store.api.StoreEntity;
import org.javacream.store.api.StoreKey;
import org.javacream.store.api.StoreService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class JpaStoreService implements StoreService{

	@Autowired
	private StoreRepo store;
	
	@Override
	public int getStock(String category, String id) {

		Integer result = store.getStock(category, id);
		if (result == null) return 0;
		else return result;

//			Optional<StoreEntity> result = store.findById(new StoreKey(category, id));
//			if (result.isEmpty()) return 0;
//			else return result.get().getStock();
	}
	
	public void setStock(String category, String id, int stock) {
		if (category == null || id == null) {
			throw new IllegalArgumentException ("category and id must not be null");
		}

		StoreEntity entity = store.save(new StoreEntity(new StoreKey(category, id), stock));
	}


}