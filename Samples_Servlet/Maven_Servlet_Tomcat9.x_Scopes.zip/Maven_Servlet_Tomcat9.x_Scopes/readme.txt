Ein erstes Servlet Maven Projekt mit aktuellen Plugin-Versionen vom Januar 2023
    + Jupiter-Dependencies
    + Servlet-Dependencies
    + Nutzung der Scopes (low level)
Muss selbst als Web-Applikation deployed werden.
Aufrufbar unter:
http://localhost:8080/Maven_Servlet_Tomcat9.x_Scopes-1.0-SNAPSHOT/karrer/scopes

Vorsicht: wir sollten dieselbe Java-Version für das Deployment nutzen, unter der auch Tomcat gestartet wird!!
z:b: Tomcat, der prinzipiell mit Java 11 umgehen kann, läuft auf Basis Java 8. Deployment ist Java 11.
Laut Tomcat-Console ist Deployment erfolgreich, funktioniert aber nicht. Leider keine Fehlermeldung!!