package beans;

import ifaces.DiffService;
import ifaces.MathService;
import ifaces.SumService;

public class MathServiceImpl implements MathService {
	
	private SumService sumService;
	private DiffService diffService;
	
	public MathServiceImpl() { 

	}

	public void setHello(SumService sumService) { // must(!) be public
		this.sumService = sumService;
	}
	
	public void setWorld(DiffService diffService) { // must(!) be public
		this.diffService = diffService;
	}

	@Override
	public int sum(int x, int y) {
		return this.sumService.sum(x, y);
	}

	@Override
	public int diff(int x, int y) {
		return this.diffService.diff(x, y);
	}
}
