package appl;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import beans.DiffServiceImpl;
import beans.SumServiceImplRecursive;
import beans.SumServiceImplSimple;
import ifaces.DiffService;
import ifaces.SumService;
import jn.util.Log;

@Configuration
public class ApplConfigSumDiff {

	public ApplConfigSumDiff() {
		Log.log();
	}
	
	@Bean(name="sumServiceSimple")
	public SumService sumServiceSimple() {
		Log.log();
		return new SumServiceImplSimple();
	}

	@Bean(name="sumServiceRecursive")
	public SumService sumServiceRecursive() {
		Log.log();
		return new SumServiceImplRecursive();
	}

	@Bean 
	public DiffService diffService() {
		Log.log();
		return new DiffServiceImpl();
	}
}
