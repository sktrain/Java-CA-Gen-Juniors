package beans;

import ifaces.MathService;

public class MathServiceImpl1 implements MathService {
	
	public MathServiceImpl1() {

	}
	
	@Override
	public int sum(int x, int y) {
		return x + y;
	}

	@Override
	public int diff(int x, int y) {
		return x - y;
	}
}
