JPA durch Spring gemanaged + deklarative Transaktionsunterstützung

+ Repository-Generierung mit 2 Entities inklusive Beziehungen.

Das ist grundsätzlich kein Problem, aber die Lazy-Beziehungen machen Probleme!!

Aber es existiert Abhilfe! (siehe auch https://www.baeldung.com/java-jpa-lazy-collections),
die hier jetzt via "Join Fetch" bzw. "Entity Graph" realisiert  wurde.