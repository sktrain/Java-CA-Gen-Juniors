package sk.train.clientSpring;

import org.apache.cxf.jaxws.JaxWsProxyFactoryBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import sk.train.handisch.WsServiceIF;

@Configuration
public class ClientConfiguration {

    // Bean definitions

    @Bean
    public JaxWsProxyFactoryBean proxyFactoryBean() {
        JaxWsProxyFactoryBean proxyFactory = new JaxWsProxyFactoryBean();
        proxyFactory.setServiceClass(WsServiceIF.class);
        proxyFactory.setAddress("http://localhost:8080/sk.train.x14_Ueb1_Solution-1.0-SNAPSHOT/services/hello_world");
        return proxyFactory;
    }

    @Bean(name = "client")
    public Object generateProxy() {
        return proxyFactoryBean().create();
    }
}