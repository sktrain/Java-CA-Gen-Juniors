Aufgabe:
Diesmal sind zwei Entities gegeben, die den Tabellen "Employees" und "Departments"
mitsamt den Schlüssel-Fremdschlüssel-Beziehungen gegeben.
Es soll ein entsprechendes rudimentäres Repository "EmpService" erstellt werden, welches
auch auf Departments zugreift.
Anschließend soll der JPA-Layer mal via Starter-Klasse initialisiert und das
Repository genutzt werden.
(Gegebener Code ist zu komplettieren und kann bei Bedarf erweitert werden).