package beans;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import ifaces.DiffService;
import ifaces.MathService;
import ifaces.SumService;
import jn.util.Log;

@Component
// @Component("Math")
public class MathServiceImpl implements MathService {
	
	private SumService sumService;
	private DiffService diffService;
	
	public MathServiceImpl() {
		Log.log();
	}
	
	@PostConstruct
	public void postConstruct() {
		Log.log();
	}

	@PreDestroy
	public void preDestroy() {
		Log.log();
	}
	
	@Autowired
	public void setSumService(SumService sumService) { 
		Log.log();
		this.sumService = sumService;
	}
	
	@Autowired
	public void setDiffService(DiffService diffService) {
		Log.log();
		this.diffService = diffService;
	}

	@Override
	public int sum(int x, int y) {
		return this.sumService.sum(x, y);
	}

	@Override
	public int diff(int x, int y) {
		return this.diffService.diff(x, y);
	}
}
