Rest mit JPA, Spring Boot und XML-MessageFormat mit Jackson
+ zusätzlich als SOAP-WS mit CXF aufrufbar! (http://localhost:8088/services/jaxwsemployee?wsdl)


Dazu sind weitere Bibliotheken im ClassPath nötig, insbesondere der CXF-Starter.
Autowiring des Repos in den WebService ist nur möglich, falls dieser durch Spring gemanaged ist (Spring-Bean).

Hier jetzt mit getrennten Controller-Klassen für XML und JSON. 
Fehler kommen allerdings stets im JSON-Format. 
Man kann aber auch die Einstellungen von Spring Boot anpassen, siehe:
https://www.baeldung.com/exception-handling-for-rest-with-spring