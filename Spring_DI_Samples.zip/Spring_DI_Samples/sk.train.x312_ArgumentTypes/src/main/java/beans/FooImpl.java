package beans;

import ifaces.Foo;

import java.awt.Point;
import java.util.Date;

public class FooImpl implements Foo {

	private String s;
	private int i;
	private double d;
	private Integer iw;
	private Double dw = 0.0;
	private Date date;
	private Point point;

	public String getS() {
		return s;
	}
	public void setS(String s) {
		this.s = s;
	}
	
	public int getI() {
		return i;
	}
	public void setI(int i) {
		this.i = i;
	}

	public double getD() {
		return d;
	}
	public void setD(double d) {
		this.d = d;
	}

	public Integer getIw() {
		return iw;
	}
	public void setIw(Integer iw) {
		this.iw = iw;
	}

	public Double getDw() {
		return dw;
	}
	public void setDw(Double dw) {
		this.dw = dw;
	}
	
	public Date getDate() {
		return this.date;
	}
	public void setDate(Date date) {
		this.date = date;
	}

	public Point getPoint() {
		return this.point;
	}
	public void setPoint(Point point) {
		this.point = point;
	}
}
