package appl;

import java.util.Comparator;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.TableModel;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import helperbeans.MaList;
import sk.train.ma.strategy.model.Mitarbeiter;
import sk.train.ma.strategy.verwaltung.MitarbeiterVerwaltungIf;

public class Application {
	public static void main(String[] args) {
		try (final AnnotationConfigApplicationContext ctx = 
				new AnnotationConfigApplicationContext("sk.train.ma.strategy.verwaltung", "helperbeans", "sk.train.ma.strategy.gui")) {
			
			MitarbeiterVerwaltungIf mv = ctx.getBean(MitarbeiterVerwaltungIf.class);
			//System.out.println(mv);
			//System.out.println("\n******************************************\n");
			//mv.getMlist(Comparator.naturalOrder()).forEach(System.out::println);
			
			MaList<Mitarbeiter> list = ctx.getBean("malist", MaList.class);

			
			List<Mitarbeiter> mlist = ctx.getBean(List.class);

			
			TableModel model = ctx.getBean("tablemodel", TableModel.class);
			
			JFrame f = new JFrame();
			JTable mytable = new JTable(model);
			JScrollPane p = new JScrollPane(mytable);
			f.add(p);
			f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			f.pack();
			f.setVisible(true);
			
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			((AbstractTableModel) model).fireTableCellUpdated(0, 1);
			
		}
	}
}