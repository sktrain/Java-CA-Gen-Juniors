package beans;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import ifaces.Instrument;
import ifaces.Performer;

@Component
@Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class Musiker implements Performer{	
	
//	@Autowired
//	@Qualifier("klavier")
	private Instrument i;
	
	//da sich Qualifier nicht vor den Konstruktor schreiben lässt
	public Musiker(@Qualifier("klavier")Instrument i) {
		this.i = i;
	}
	
	public void perform() {
		System.out.println("Performamce von " + this);
		i.play();
	}
}
