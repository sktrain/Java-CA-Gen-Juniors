package app;

import app.dao.EmpRepository;
import org.apache.cxf.Bus;
import org.apache.cxf.jaxws.EndpointImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;

import javax.xml.ws.Endpoint;

@SpringBootApplication
public class EmployeeServiceStarter {

	public static void main(String[] args) {
		ConfigurableApplicationContext ctx = SpringApplication.run(EmployeeServiceStarter.class);
		
	}

	@Autowired
	EmpRepository repo;

	@Autowired
	private Bus bus;

	@Bean
	public WSImplementor getImplementor(){
		return new WSImplementor();
	}

	@Bean
	public Endpoint endpoint() {
//		WSImplementor serv = new WSImplementor();
//		serv.setRepository(repo);
		EndpointImpl endpoint = new EndpointImpl(bus, getImplementor());
		endpoint.publish("/jaxwsemployee");
		return endpoint;
	}


}