package sk.train.ma.strategy.model;

import java.math.BigDecimal;
import org.springframework.beans.factory.annotation.Value;

public class GehaltsmodellFactory implements GehaltsmodellFactoryIf {
	
	//@Value("${fgehalt}")
	private int fgehalt;
	//@Value("${astdlohn}")
	private int astdlohn;
	//@Value("${astdzahl}")
	private int astdzahl;

	public GehaltsmodellFactory(int fgehalt, int astdlohn, int astdzahl) {
		this.fgehalt = fgehalt;
		this.astdlohn = astdlohn;
		this.astdzahl = astdzahl;
	}

	@Override
	public Gehaltsmodell getGehaltsmodell(String type) {

		if (type.equals("A"))
			return new ArbeiterModell(new BigDecimal((int)(Math.random()* astdlohn)),
					new BigDecimal(astdzahl));
		else return new FixGehaltModell(new BigDecimal((int)(Math.random()* fgehalt)));
	}

}
