package beans;

import java.io.Closeable;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;

import jn.util.Log;

public class FileLogger implements Closeable {

	private final PrintWriter writer;

	public FileLogger(String filename) throws IOException {
		Log.log();
		this.writer = new PrintWriter(new FileOutputStream(filename), true);
	}

	public void log(String s) {
		this.writer.println(s);
	}

	@Override
	public void close() throws IOException {
		Log.log();
		this.writer.close();
	}
}
