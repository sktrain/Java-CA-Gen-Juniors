package appl;

import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionCallbackWithoutResult;
import org.springframework.transaction.support.TransactionTemplate;

import domain.Account;
import services.AccountService;

public class Application {

	public static void main(String[] args) {
		
		try (final AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext("appl")) {
					
			final PlatformTransactionManager tm = ctx.getBean(PlatformTransactionManager.class);
			final AccountService accountService = ctx.getBean(AccountService.class);
			
			System.err.println("************************* Before ************************");
			List<Account> list = findAllAccounts(tm, accountService);
			list.forEach(System.err::println);

			createAccount(tm, accountService, 4711);
			createAccount(tm, accountService, 4712);
			deposit(tm, accountService, 4711, 5000);
			deposit(tm, accountService, 4712, 6000);
			withdraw(tm, accountService, 4711, 2000);
			transfer(tm, accountService, 4711, 4712, 500);
			// transfer(tm, accountService, 4711, 4712, 50000);

			System.err.println("************************* After ************************");
			list = findAllAccounts(tm, accountService);
			list.forEach(System.out::println);
		}
	}

	private static void createAccount(PlatformTransactionManager tm, AccountService accountService, int number) {
		final DefaultTransactionDefinition td = new DefaultTransactionDefinition();
		td.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRED);
		final TransactionStatus ts = tm.getTransaction(td);
		try {
			accountService.createAccount(number);
			tm.commit(ts);
		}
		catch (final RuntimeException e) {
			tm.rollback(ts);
			throw e;
		}
	}

	private static void deposit(PlatformTransactionManager tm, AccountService accountService, int number, int amount) {
		final DefaultTransactionDefinition td = new DefaultTransactionDefinition();
		td.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRED);
		final TransactionStatus ts = tm.getTransaction(td);
		try {
			accountService.deposit(number, amount);
			tm.commit(ts);
		}
		catch (final RuntimeException e) {
			tm.rollback(ts);
			throw e;
		}
	}

	private static void withdraw(PlatformTransactionManager tm, AccountService accountService, int number, int amount) {
		final DefaultTransactionDefinition td = new DefaultTransactionDefinition();
		td.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRED);
		final TransactionStatus ts = tm.getTransaction(td);
		try {
			accountService.withdraw(number, amount);
			tm.commit(ts);
		}
		catch (final RuntimeException e) {
			tm.rollback(ts);
			throw e;
		}
	}

	private static void transfer(PlatformTransactionManager tm, AccountService accountService, int fromNumber,
								 int toNumber, int amount) {
		final DefaultTransactionDefinition td = new DefaultTransactionDefinition();
		td.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRED);
		final TransactionStatus ts = tm.getTransaction(td);
		try {
			accountService.transfer(fromNumber, toNumber, amount);
			tm.commit(ts);
		}
		catch (final RuntimeException e) {
			tm.rollback(ts);
			throw e;
		}
	}

	private static List<Account> findAllAccounts(PlatformTransactionManager tm, AccountService accountService) {
		final DefaultTransactionDefinition td = new DefaultTransactionDefinition();
		td.setPropagationBehavior(TransactionDefinition.PROPAGATION_SUPPORTS);
		final TransactionStatus ts = tm.getTransaction(td);
		try {
			final List<Account> list = accountService.findAllAccounts();
			tm.commit(ts);
			return list;
		}
		catch (final RuntimeException e) {
			tm.rollback(ts);
			throw e;
		}
	}
}
