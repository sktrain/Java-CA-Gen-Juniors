package ifaces;

public interface Instrument {
	public abstract void play();
}

