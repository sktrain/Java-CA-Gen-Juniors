package appl;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import ifaces.DiffService;
import ifaces.MathService;
import ifaces.SumService;

public class Application {
	public static void main(String[] args) {
		try (final ClassPathXmlApplicationContext ctx = 
				new ClassPathXmlApplicationContext("spring.xml")) {
			final MathService mathService1 = ctx.getBean(MathService.class);
			System.out.println(mathService1.sum(40, 2));
			System.out.println(mathService1.diff(80, 3));

			final MathService mathService2 = ctx.getBean(MathService.class);
			System.out.println(mathService2.sum(40, 2));
			System.out.println(mathService2.diff(80, 3));

			System.out.println(mathService1 == mathService2);
			
			// final SumService sumService = ctx.getBean("sumService", SumService.class);
			final SumService sumService = ctx.getBean(SumService.class);
			System.out.println(sumService.sum(40, 2));

			final DiffService diffService = ctx.getBean(DiffService.class);
			System.out.println(diffService.diff(80, 3));
		}
	}
}
