package sk.train;

public class RequestBean {

}
