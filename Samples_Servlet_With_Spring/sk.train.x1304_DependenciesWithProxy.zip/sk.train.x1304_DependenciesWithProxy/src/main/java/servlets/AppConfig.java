package servlets;

import beans.ApplicationBean;
import beans.RequestBean;
import beans.SessionBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.web.context.WebApplicationContext;

@Configuration
public class AppConfig {

    @Bean(name ="requestBean")
    @Scope(value = WebApplicationContext.SCOPE_REQUEST, proxyMode= ScopedProxyMode.TARGET_CLASS)
    public RequestBean requestBean() {
        return new RequestBean();
    }

    @Bean(name ="sessionBean")
    @Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode=ScopedProxyMode.TARGET_CLASS)
    public SessionBean sessionBean() {
        return new SessionBean(requestBean());
    }

    @Bean(name ="applicationBean")
    @Scope(WebApplicationContext.SCOPE_APPLICATION)
    public ApplicationBean applicationBean() {
        return new ApplicationBean(sessionBean());
    }

}
