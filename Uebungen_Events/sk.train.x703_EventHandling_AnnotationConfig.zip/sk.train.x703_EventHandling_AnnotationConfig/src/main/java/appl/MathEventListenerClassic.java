package appl;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationListener;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.stereotype.Component;

@Component
public class MathEventListenerClassic implements ApplicationListener<MathEvent>{
	
	@Autowired
	ConfigurableApplicationContext ctx;
	
	@PostConstruct
	public void init() {
		ctx.addApplicationListener(this);
	}
	
	@Override
	public void onApplicationEvent(MathEvent event) {
		System.out.println("MathEventListenerClassic" +	": " + event);
		
	}

}
