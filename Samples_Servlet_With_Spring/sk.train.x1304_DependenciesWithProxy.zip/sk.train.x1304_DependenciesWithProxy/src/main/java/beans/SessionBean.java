package beans;


public class SessionBean {
	private final RequestBean requestBean;
	public SessionBean(RequestBean requestBean) {
		System.out.println(this.getClass().getSimpleName() + "()");
		this.requestBean = requestBean;
	}
	public RequestBean getRequestBean() {
		return this.requestBean;
	}
}
