Web-Projekt mit Spring-Security mit Passwort-Datenbank

Folgendes Skript (auf Basis H2) muss vorab in der Datenbank ausgeführt werden:
create table users(username varchar_ignorecase(50) not null primary key,password varchar_ignorecase(500) not null,enabled boolean not null);
create table authorities (username varchar_ignorecase(50) not null,authority varchar_ignorecase(50) not null,constraint fk_authorities_users foreign key(username) references users(username));
Optional:
create unique index ix_auth_username on authorities (username,authority);


Basiert auf sk.train.x14_04_JPA_Rest_SOAP_Boot_Solution

(Rest mit JPA, Spring Boot und XML-MessageFormat mit Jackson
+ zusätzlich als SOAP-WS mit CXF aufrufbar: http://localhost:8088/services/jaxwsemployee?wsdl
)

