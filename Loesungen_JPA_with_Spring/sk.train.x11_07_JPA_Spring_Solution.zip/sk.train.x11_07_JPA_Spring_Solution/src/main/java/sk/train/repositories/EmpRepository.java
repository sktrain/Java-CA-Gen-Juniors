package sk.train.repositories;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import model.Employee;
import org.springframework.data.repository.query.Param;
import org.springframework.data.util.Streamable;

import javax.transaction.Transactional;

//@Transactional(value = Transactional.TxType.SUPPORTS)
public interface EmpRepository  extends JpaRepository<Employee, Long>{
	
	public abstract List<Employee> findBySalary(BigDecimal salary);
	
	public abstract List<Employee> findBySalaryLessThan(BigDecimal salary);
	
	public abstract Optional<Employee> findByEmployeeIdAndSalary(long id, BigDecimal salary);
	
	@Query("select sum(e.salary)from Employee e")
	public abstract BigDecimal getSumSalary();

	@Query("select c from Employee c where c.employeeId in" +
			"(select distinct e.managerId from Employee e)")
	public abstract List<Employee> getManagers();

	@Query("select c from Employee c where c.employeeId not in" +
			"(select distinct e.managerId from Employee e)")
	public abstract List<Employee> getNoManagers();


	//Spezialfall Streaming
	@Query("select e from Employee e where e.salary > :sal")
	public abstract Streamable<Employee> getEmpStream(@Param("sal") BigDecimal sal);


	//Spezialfall Native Query
	@Query(value = "select * from hr.employees where employee_id in" +
			"(select distinct manager_id from hr.employees)", nativeQuery = true)
	public abstract  List<Employee> getManagersNative();



}
