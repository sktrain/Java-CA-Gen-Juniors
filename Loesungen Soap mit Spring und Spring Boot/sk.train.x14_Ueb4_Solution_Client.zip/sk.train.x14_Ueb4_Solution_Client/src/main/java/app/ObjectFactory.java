
package app;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the app package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _AllEmps_QNAME = new QName("http://app/", "allEmps");
    private final static QName _AllEmpsResponse_QNAME = new QName("http://app/", "allEmpsResponse");
    private final static QName _EmpById_QNAME = new QName("http://app/", "empById");
    private final static QName _EmpByIdResponse_QNAME = new QName("http://app/", "empByIdResponse");
    private final static QName _Employee_QNAME = new QName("http://app/", "employee");
    private final static QName _SaveEmp_QNAME = new QName("http://app/", "saveEmp");
    private final static QName _SaveEmpResponse_QNAME = new QName("http://app/", "saveEmpResponse");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: app
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link AllEmps }
     * 
     */
    public AllEmps createAllEmps() {
        return new AllEmps();
    }

    /**
     * Create an instance of {@link AllEmpsResponse }
     * 
     */
    public AllEmpsResponse createAllEmpsResponse() {
        return new AllEmpsResponse();
    }

    /**
     * Create an instance of {@link EmpById }
     * 
     */
    public EmpById createEmpById() {
        return new EmpById();
    }

    /**
     * Create an instance of {@link EmpByIdResponse }
     * 
     */
    public EmpByIdResponse createEmpByIdResponse() {
        return new EmpByIdResponse();
    }

    /**
     * Create an instance of {@link Employee }
     * 
     */
    public Employee createEmployee() {
        return new Employee();
    }

    /**
     * Create an instance of {@link SaveEmp }
     * 
     */
    public SaveEmp createSaveEmp() {
        return new SaveEmp();
    }

    /**
     * Create an instance of {@link SaveEmpResponse }
     * 
     */
    public SaveEmpResponse createSaveEmpResponse() {
        return new SaveEmpResponse();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AllEmps }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link AllEmps }{@code >}
     */
    @XmlElementDecl(namespace = "http://app/", name = "allEmps")
    public JAXBElement<AllEmps> createAllEmps(AllEmps value) {
        return new JAXBElement<AllEmps>(_AllEmps_QNAME, AllEmps.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AllEmpsResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link AllEmpsResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://app/", name = "allEmpsResponse")
    public JAXBElement<AllEmpsResponse> createAllEmpsResponse(AllEmpsResponse value) {
        return new JAXBElement<AllEmpsResponse>(_AllEmpsResponse_QNAME, AllEmpsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link EmpById }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link EmpById }{@code >}
     */
    @XmlElementDecl(namespace = "http://app/", name = "empById")
    public JAXBElement<EmpById> createEmpById(EmpById value) {
        return new JAXBElement<EmpById>(_EmpById_QNAME, EmpById.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link EmpByIdResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link EmpByIdResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://app/", name = "empByIdResponse")
    public JAXBElement<EmpByIdResponse> createEmpByIdResponse(EmpByIdResponse value) {
        return new JAXBElement<EmpByIdResponse>(_EmpByIdResponse_QNAME, EmpByIdResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Employee }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link Employee }{@code >}
     */
    @XmlElementDecl(namespace = "http://app/", name = "employee")
    public JAXBElement<Employee> createEmployee(Employee value) {
        return new JAXBElement<Employee>(_Employee_QNAME, Employee.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SaveEmp }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link SaveEmp }{@code >}
     */
    @XmlElementDecl(namespace = "http://app/", name = "saveEmp")
    public JAXBElement<SaveEmp> createSaveEmp(SaveEmp value) {
        return new JAXBElement<SaveEmp>(_SaveEmp_QNAME, SaveEmp.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SaveEmpResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link SaveEmpResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://app/", name = "saveEmpResponse")
    public JAXBElement<SaveEmpResponse> createSaveEmpResponse(SaveEmpResponse value) {
        return new JAXBElement<SaveEmpResponse>(_SaveEmpResponse_QNAME, SaveEmpResponse.class, null, value);
    }

}
