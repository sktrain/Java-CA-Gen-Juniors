package beans;

import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import ifaces.MathService;
import jn.util.Log;

@Component
@Scope(ConfigurableBeanFactory.SCOPE_SINGLETON)  // the default
public class MathServiceImpl implements MathService {

	public MathServiceImpl() {
		Log.log();
	}
	public int sum(int x, int y) {
		return x + y;
	}
	public int diff(int x, int y) {
		return x - y;
	}
}
