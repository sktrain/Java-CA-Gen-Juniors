package appl;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import ifaces.Foo;

public class Application {
	public static void main(String[] args) {
		try (ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("spring.xml")) {
			System.out.println();
			final Foo foo1 = ctx.getBean("foo1", Foo.class);
			print(foo1);
			System.out.println();
			final Foo foo2 = ctx.getBean("foo2", Foo.class);
			print(foo2);
		}
	}

	private static void print(Foo foo) {
		System.out.println(foo.getS());
		System.out.println(foo.getI());
		System.out.println(foo.getD());
		System.out.println(foo.getIw());
		System.out.println(foo.getDw());
		System.out.println(foo.getDate());
		System.out.println(foo.getPoint());
	}
}
