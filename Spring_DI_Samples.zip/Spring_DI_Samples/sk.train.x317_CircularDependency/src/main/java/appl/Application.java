package appl;

import ifaces.MathService;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Application {
	public static void main(String[] args) {
		try (ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("spring.xml")) {
			final MathService mathService = ctx.getBean(MathService.class);
			System.out.println(mathService.sum(40, 2));
			System.out.println(mathService.diff(80, 3));
		}
	}
}
