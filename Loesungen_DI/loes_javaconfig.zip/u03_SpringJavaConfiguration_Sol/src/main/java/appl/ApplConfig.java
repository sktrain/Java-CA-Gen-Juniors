package appl;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import processor.Database;
import processor.GroupChangeProcessor;
import processor.OrderPrinter;
import processor.OrderReader;
import processor.impl.DatabaseDummy;
import processor.impl.GroupChangeProcessorImpl;
import processor.impl.SimpleOrderPrinter;
import processor.impl.SimpleOrderReader;

@Configuration
public class ApplConfig {

	// <bean id="reader" class="processor.impl.SimpleOrderReader">
	// <property name="filename" value="src/main/resources/orders.txt" />
	// </bean>

	@Bean
	public OrderReader reader() {

		SimpleOrderReader reader = new SimpleOrderReader();
		reader.setFilename("src/main/resources/orders.txt");
		return reader;
	}

	// <bean id="database" class="processor.impl.DatabaseDummy" />
	
	@Bean
	public Database database() {
		return new DatabaseDummy();
	}
	
	// <bean id="printer" class="processor.impl.SimpleOrderPrinter" />

	@Bean
	public OrderPrinter printer() {
		return new SimpleOrderPrinter();
	}
	
	
	// <bean id="gcp" class="processor.impl.GroupChangeProcessorImpl">
	// <property name="reader" ref="reader" />
	// <property name="database" ref="database" />
	// <property name="printer" ref="printer" />

	@Bean(name="gcp")
	public GroupChangeProcessor gproc() {
		GroupChangeProcessorImpl gcp = new GroupChangeProcessorImpl();
		gcp.setDatabase(database());
		gcp.setReader(reader());
		gcp.setPrinter(printer());
		return gcp;
	}

}
